<?php
$route['orders'] = 'orders';
$route['addorder'] = 'orders/add';
$route['ajaxorder'] = 'orders/ajax';
$route['deleteorder'] = 'orders/delete';
?>