<?php
$route['inventorys'] = 'inventory';
$route['addinventory'] = 'inventory/add';
$route['ajaxinventory'] = 'inventory/ajax';
$route['deleteinventory'] = 'inventory/delete';
?>