<?php
$route['invoices'] = 'invoice';
$route['addinvoice'] = 'invoice/add';
$route['ajaxinvoice'] = 'invoice/ajax';
$route['deleteinvoice'] = 'invoice/delete';
?>