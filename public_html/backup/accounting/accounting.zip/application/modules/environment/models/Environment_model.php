<?php
class Environment_model extends Common_model{
    public function __construct(){
        parent::__construct();
    }

    public function all($search = []){

    }

    public function count($search = []){

    }
}