<?php
$route['environment'] = 'environment';
?>