<div class="row mainbox">
    Administrator Panel
</div>