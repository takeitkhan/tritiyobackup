<div class="row mainbox">
    <table id="allusers" class="display" cellspacing="0" width="100%" class="table table-striped table-bordered">
        <thead>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Created Date</th>
            <th>Email</th>
            <th>Company</th>
            <th>Phone</th>
        </tr>
        </thead>

        <tfoot>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Created Date</th>
            <th>Email</th>
            <th>Company</th>
            <th>Phone</th>
        </tr>
        </tfoot>
    </table>
</div>