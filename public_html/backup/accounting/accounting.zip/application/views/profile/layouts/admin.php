<div class="x_panel">
    <div class="x_title">
        <?php settingHTML('Overview & Stats'); ?>
        <div class="clearfix"></div>
    </div>
    <div class="x_content" style="display: block;">
        <div class="page-header">

        </div>
    </div>
</div>
<div class="x_panel">
    <div class="x_title">
        <div class="clearfix"></div>
    </div>
    <div class="x_content" style="display: block;">
        <div class="page-header">            

        </div>
    </div>
</div>
<div class="row">

</div>