<ul>
    <li>Personal &amp; Community Profile</li>
    <li>Targeted Live Chat</li>
    <li>Targeted News Feed</li>
    <li>Virtual Viral Biz Card</li>
    <li>25% Affiliate Commissions</li>
    <li>Quick &amp; Easy Donation Link</li>
    <li>Commissions &amp; Payment Portal</li>
    <li>Concurrent Social Media Posts</li>
    <li>Personal &amp; Community Ecommerce</li>
    <li>25% Commissions for Advertising</li>
    <li>25% Commissions for Subscriptions</li>
    <li>Personal &amp; Community Crowdfunding</li>
    <li>Secure &amp; Private Admin Access &amp; Settings</li>
    <li>Download &amp; Invite Social, Phone, Email &amp; other Data Bases</li>
    <li>Referral Rewards</li>
    <li>Search Engine Optimization</li>
    <li>Like Minded Green Directory (CRM)</li>
    <li>Personal &amp; Community Event Section</li>
    <li>Personal &amp; Community Employment Sections</li>
    <li>Automated Emails</li>
    <li>Calendar-Scheduling</li>
    <li>Analytics Administration</li>
    <li>Personal &amp; Community Road Shows</li>
    <li>Personal &amp; Community Radio Shows</li>
    <li>Video Marketing</li>
    <li>Business Coaching</li>
    <li>CrowdFunding Coaching</li>
    <li>PR/Marketing Campaigns</li>
    <li>Search Engine Marketing</li>
    <li>Free Trademark Searches</li>
    <li>Low Cost Patent Searches</li>
    <li>Free Legal Patent Opinions</li>
    <li>Licensing Contracts Review</li>
    <li>Event/Trade Show Representation</li>
    <li>High Value Inventor/Investor Workshops</li>
    <li>(CRM) 2,500 - Unlimited Limit Contacts Relationship Management</li>
    <li>25,000 Reporters NYT, ABC, CNN, etc</li>
    <li>Press Releases</li>
    <li>Call Center from Laptop &amp; Access to Millions of Targeted Leads &amp; Contacts</li>
</ul>