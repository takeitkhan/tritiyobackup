<div class="col-md-3 col-xs-18 box3 sidebar">
    <div class="col-md-12 col-xs-18 box12">
        <h5>ADS THAT PAY YOU 25% COMMISSION</h5>

        <div class="thumbnail">
            <img src="http://placehold.it/500x300" alt=""/>
        </div>
    </div>
    <div class="col-md-12 col-xs-18 box12">
        <h5>ADS THAT PAY YOU 25% COMMISSION</h5>

        <div class="thumbnail">
            <img src="http://placehold.it/500x300" alt=""/>
        </div>
    </div>
    <div class="col-md-12 col-xs-18 box12 latestnews">
        <h5>TARGETED NEWS FEED</h5>

        <div class="singlelnews">
            <h6><a href="#">Donald Trump unveils </a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>Republican presidential front-runner Donald Trump, as part of a plan he said Monday would grow the U.S. economy</p>
        </div>
        <hr/>
        <div class="singlelnews">
            <h6><a href="#">Reuters Afghan Taliban seize Kunduz city center in landmark gain</a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>Afghanistan Taliban fighters on Monday battled their way into the center of Kunduz, a city in northern Afghanistan</p>
        </div>
        <hr/>
        <div class="singlelnews">
            <h6><a href="#">Wall Street Journal Journalist, tap dancer among 2015 genius grant winners</a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>A journalist whose work focuses on race and racism in the United States and a New York City tap dancer and choreographer</p>
        </div>
        <hr/>
        <div class="singlelnews">
            <h6><a href="#">Minneapolis Star Tribune Two killed and three</a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>Two women were killed and two men and an infant were wounded in a shooting on Monday night in Chicago, police said.</p>
        </div>
        <hr/>
        <div class="singlelnews">
            <h6><a href="#">Expert Views - RBI rate cut positive for growth and markets</a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>MUMBAI The Reserve Bank of India (RBI) cut its key repo rate by a bigger-than-expected 50 basis points to 6.75 percent on Tuesday</p>
        </div>
        <hr/>
        <div class="singlelnews">
            <h6><a href="#">Sustainability: Always Worthy, But Suddenly Far From Boring</a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>The trouble with �sustainability� is that for far too long it has been seen in the U.K. by the mainstream business media as worthy, but boring.</p>
        </div>
        <hr/>
        <div class="singlelnews">
            <h6><a href="#">Increased student interest leads</a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>Efforts to improve sustainability have expanded at the U in recent years, in part due to a rise in student interest.</p>
        </div>
        <hr/>
        <div class="singlelnews">
            <h6><a href="#">Millersville University hires first sustainability manager</a></h6>
            <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>

            <p>He had been a senior sustainability manager at ICF International in Washington D.C. since 2004, helping lead ICF's multi-million dollar sustainability project portfolio.</p>
        </div>
        <hr/>
    </div>

</div>