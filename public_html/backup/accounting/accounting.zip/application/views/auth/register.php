<div class="row mainbox">
Registration Page
</div>

