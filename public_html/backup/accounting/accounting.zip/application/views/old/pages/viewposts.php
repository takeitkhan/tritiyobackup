<div class="row mainbox">
    <table id="allposts" class="display" cellspacing="0" width="100%" class="table table-striped table-bordered">
        <thead>
        <tr>
            <th>Post ID</th>
            <th>Title</th>
            <th>Post Route</th>
            <th>Category</th>
            <th>Content</th>
            <th>Media</th>
            <th>Published</th>
            <th>Active</th>
            <th width="10">Edit</th>
            <th width="10">Delete</th>
        </tr>
        </thead>

        <tfoot>
        <tr>
            <th>Post ID</th>
            <th>Title</th>
            <th>Post Route</th>
            <th>Category</th>
            <th>Content</th>
            <th>Media</th>
            <th>Published</th>
            <th>Active</th>
            <th width="10">Edit</th>
            <th width="10">Delete</th>
        </tr>
        </tfoot>
    </table>
</div>