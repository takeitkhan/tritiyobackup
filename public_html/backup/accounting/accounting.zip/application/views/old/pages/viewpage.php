<div class="row mainbox">
    <table id="allpages" class="display" cellspacing="0" width="100%" class="table table-striped table-bordered">
        <thead>
        <tr>
            <th>Page ID</th>
            <th>Page Title</th>
            <th>Page Route</th>
            <th>Parent Page</th>
            <th>Published Date</th>
            <th>Is Active</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </thead>

        <tfoot>
        <tr>
        	<th>Page ID</th>
            <th>Page Title</th>
            <th>Page Route</th>
            <th>Parent Page</th>
            <th>Published Date</th>
            <th>Is Active</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </tfoot>
    </table>
</div>