<div class="row mainbox">
    <table id="allapplicants" class="display" cellspacing="0" width="100%" class="table table-striped table-bordered">
        <thead>
        <tr>
            <th>UserID</th>
            <th>Gender</th>
            <th>EnrollmentStatus</th>
            <th>DOB</th>
            <th>Full Name (bn)</th>
            <th>Full Name (en)</th>
            <th>Fathers Name (bn)</th>
            <th>Fathers Name (en)</th>
            <th>Mother Name(bn)</th>
            <th>Mother Name(en)</th>
            <th>View</th>
            <th>Delete</th>
        </tr>
        </thead>

        <tfoot>
        <tr>
            <th>UserID</th>
            <th>Gender</th>
            <th>EnrollmentStatus</th>
            <th>DOB</th>
            <th>Full Name (bn)</th>
            <th>Full Name (en)</th>
            <th>Fathers Name (bn)</th>
            <th>Fathers Name (en)</th>
            <th>Mother Name(bn)</th>
            <th>Mother Name(en)</th>
            <th>View</th>
            <th>Delete</th>
        </tr>
        </tfoot>
    </table>
</div>


