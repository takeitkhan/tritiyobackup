<?php
	owndebugger($written);
?>