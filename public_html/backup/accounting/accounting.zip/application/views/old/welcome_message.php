<div class="starter-template">
    <!-- Common Start -->


    <div class="row mainbox">

        <div class="col-md-9 col-xs-13 box9">
            <div class="row">
                <div class="col-md-4">
                    <img src="http://www.morganstanley.com/assets/images/people/tiles/adam-parker-large.jpg"
                         alt="Profile Photo" class="img-thumbnail">
                </div>
                <div class="col-md-8">
                    <h1>Morgan Smith vul hoise</h1>				

                    <h3>Executive Manager</h3>
					ok now Nonwo oko
					Ki koili
					llll
					<h3>Executive Manager</h3>
                    <hr/>
                    <div class="row">
                        <div class="col-md-4">
                            Studied at
                        </div>
                        <div class="col-md-8">
                            University of Massachusetts
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Lives In
                        </div>
                        <div class="col-md-8">
                            California, USA
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            From
                        </div>
                        <div class="col-md-8">
                            New York, USA
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-md-12 col-xs-18">
                            <a class="btn btn-success">Edit Profile</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tenpxm"></div>
            <hr/>
            <h3>Overview</h3>

            <div class="row overviewmainbox">

                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/interestLanding.PNG' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Viral Biz Card</h3>
                            Total: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">Download Viral Biz Card</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Send Viral Biz Card</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/landingOrganization.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Personal eCommerce</h3>
                            Total Products: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">My Products</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Add New Product</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/summaryLanding.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Events</h3>
                            Total: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">My Events</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Add New Event</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/interestLanding.PNG' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Jobs</h3>
                            Total Products: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">My Jobs</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Add New Job</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/landingOrganization.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>CrowdFunding</h3>
                            Total: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">My Projects</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Add New Project</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/photoLanding.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Green Directory</h3>
                            Total Products: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">My Businesses</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Add New Business</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/summaryLanding.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Press Releases</h3>
                            Total: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">Approved Press Releases</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Send New Press Release</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/honsLanding.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Jobs</h3>
                            Total Products: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">My Jobs</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Add New Job</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/photoLanding.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Radio Shows</h3>
                            Total: 3032
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">My Radio Shows</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Add New Show</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 overviewbox">
                    <div class="ovvbox">
                        <div class="col-md-3">
                            <a href="#"><img src="<?php echo base_url() . '/footprints/img/honsLanding.png' ?>"
                                             alt="summaryLanding"/></a>
                        </div>
                        <div class="col-md-9">
                            <h3>Schedule Calendar</h3>
                            Appointment this week: 5
                            <br/>
                            Appointment next week: 10
                        </div>
                        <div class="clearfix"></div>
                        <div class="row ovvbtn">
                            <div class="col-md-6">
                                <a href="#">Check Appointments</a>
                            </div>
                            <div class="col-md-6">
                                <a href="#">Check New Requests</a>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <hr/>
            <div class="events">
                <h3>My Recent Events</h3>

                <div class="row">
                    <div class="recentevents">
                        <div class="col-md-10">
                            <h4>I Gave my Dog a Job Mel Riley</h4>
                            <small class="greytext">July 26 @ 7:00 pm - 8:00 pm</small>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-success">Free</button>
                        </div>
                    </div>
                </div>
                <div class="tenpxm"></div>
                <div class="row">
                    <div class="recentevents">
                        <div class="col-md-10">
                            <h4>I Gave my Dog a Job Mel Riley</h4>
                            <small class="greytext">July 26 @ 7:00 pm - 8:00 pm</small>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-success">Free</button>
                        </div>
                    </div>
                </div>
                <div class="tenpxm"></div>
                <div class="row">
                    <div class="recentevents">
                        <div class="col-md-10">
                            <h4>I Gave my Dog a Job Mel Riley</h4>
                            <small class="greytext">July 26 @ 7:00 pm - 8:00 pm</small>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-success">Free</button>
                        </div>
                    </div>
                </div>
                <div class="tenpxm"></div>
                <div class="row">
                    <div class="recentevents">
                        <div class="col-md-10">
                            <h4>I Gave my Dog a Job Mel Riley</h4>
                            <small class="greytext">July 26 @ 7:00 pm - 8:00 pm</small>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-success">Free</button>
                        </div>
                    </div>
                </div>
                <div class="tenpxm"></div>
                <div class="row">
                    <div class="recentevents">
                        <div class="col-md-10">
                            <h4>I Gave my Dog a Job Mel Riley</h4>
                            <small class="greytext">July 26 @ 7:00 pm - 8:00 pm</small>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-success">Free</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tenpxm"></div>
            <hr/>
            <h3>My Recent Products</h3>

            <div class="products">
                <div class="row">
                    <div class="col-xs-18 col-sm-6 col-md-4">
                        <div class="thumbnail">
                            <img src="http://placehold.it/500x300" alt="">

                            <div class="caption">
                                <h4>Thumbnail label</h4>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere, soluta, eligendi
                                    doloribus sunt minus amet sit debitis repellat. Consectetur, culpa itaque odio
                                    similique
                                    suscipit</p>

                                <p><a href="#" class="btn btn-info btn-xs" role="button">Button</a>
                                    <a href="#" class="btn btn-default btn-xs" role="button">Button</a>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-18 col-sm-6 col-md-4">
                        <div class="thumbnail">
                            <img src="http://placehold.it/500x300" alt="">

                            <div class="caption">
                                <h4>Thumbnail label</h4>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere, soluta, eligendi
                                    doloribus sunt minus amet sit debitis repellat. Consectetur, culpa itaque odio
                                    similique
                                    suscipit</p>

                                <p><a href="#" class="btn btn-info btn-xs" role="button">Button</a>
                                    <a href="#" class="btn btn-default btn-xs" role="button">Button</a>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-18 col-sm-6 col-md-4">
                        <div class="thumbnail">
                            <img src="http://placehold.it/500x300" alt="">

                            <div class="caption">
                                <h4>Thumbnail label</h4>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere, soluta, eligendi
                                    doloribus sunt minus amet sit debitis repellat. Consectetur, culpa itaque odio
                                    similique
                                    suscipit</p>

                                <p><a href="#" class="btn btn-info btn-xs" role="button">Button</a>
                                    <a href="#" class="btn btn-default btn-xs" role="button">Button</a>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>


        <div class="col-md-3 col-xs-5 box3 sidebar">
            <div class="col-md-12 col-xs-18 box12">
                <h5>RECOMMENDED</h5>
                <div class="thumbnail">
                    <img src="http://placehold.it/500x300" alt=""/>
                </div>
            </div>
            <div class="col-md-12 col-xs-18 box12">
                <h5>ADS</h5>
                <div class="thumbnail">
                    <img src="http://placehold.it/500x300" alt=""/>
                </div>
            </div>
            <div class="col-md-12 col-xs-18 box12 latestnews">
                <h5>LATEST NEWS</h5>
                <div class="singlelnews">
                    <h6><a href="#">Eurozone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Euro zone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozoneagr eement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozo neagreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
                <div class="singlelnews">
                    <h6><a href="#">Eurozone agreement</a></h6>
                    <span><small>20 minutes ago | <a href="" target="_blank">New York Times</a></small></span>
                    <p>Eurozone leaders reach a "unanimous" agreement over...</p>
                </div>
                <hr/>
            </div>

        </div>

    </div>

</div>
