<div class="row">
    <div class="col-md-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Add New
                    <small> student or staff</small>
                </h2>
                <?php echo settings_icons(); ?>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <br/>
                <a href="<?php echo base_url('newstudent') ?>" class="btn btn-success">Add Student</a>
                <a href="<?php echo base_url('newstaff') ?>"  class="btn btn-success">Add Staff</a>
            </div>
        </div>
    </div>
</div>