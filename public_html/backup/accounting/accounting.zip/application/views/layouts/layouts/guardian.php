<li class="vn">
    <a><i class="fa fa-bar-chart-o"></i> Reports as guardian<span class="fa fa-chevron-down"></span></a>
    <ul style="display: none;" class="nav child_menu">
        <li><a href="<?php __menu("mystudents") ?>">My Students</a></li>
        <li><a href="<?php __menu("getstdattendancereport") ?>">Get Attendance Report</a></li>
        <li><a href="<?php __menu("getstdresultreport") ?>">Get Result Report</a></li>
        <li><a style="color: greenyellow !important;" href="<?php __menu("getmoneyreceipt") ?>">Print
                Money Receipt</a></li>
    </ul>
</li>
<li class="vn">
    <a><i class="fa fa-file"></i> Requests<span class="fa fa-chevron-down"></span></a>
    <ul style="display: none;" class="nav child_menu">
        <li><a href="<?php __menu("askleaves") ?>">Leave</a></li>
        <li><a href="<?php __menu("askbooks") ?>">Book</a></li>
        <li><a href="<?php __menu("asktestimonial") ?>">Testimonial</a></li>
        <li><a href="<?php __menu("asktransfercertificate") ?>">Transfer Certificate</a></li>
    </ul>
</li>