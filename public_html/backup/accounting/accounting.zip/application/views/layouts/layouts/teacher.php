<li class="vn">
    <a><i class="fa fa-bar-chart-o"></i> Reports as teacher<span class="fa fa-chevron-down"></span></a>
    <ul style="display: none;" class="nav child_menu">
        <li><a href="<?php __menu("getstdattendancereport") ?>">Get Attendance Report</a></li>
        <li><a style="color: orange !important;" href="<?php __menu("getpayslip") ?>">Print Pay
                Slip</a></li>
    </ul>
</li>