<style>
    @font-face {
        font-family: 'Glyphicons Halflings';
        src: url('<?php echo base_url(); ?>fonts/glyphicons-halflings-regular.eot');
        src: url('<?php echo base_url(); ?>fonts/glyphicons-halflings-regular.eot?#iefix') format('embedded-opentype'),
        url('<?php echo base_url(); ?>fonts/glyphicons-halflings-regular.woff2') format('woff2'),
        url('<?php echo base_url(); ?>fonts/glyphicons-halflings-regular.woff') format('woff'),
        url('<?php echo base_url(); ?>fonts/glyphicons-halflings-regular.ttf') format('truetype'),
        url('<?php echo base_url(); ?>fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular') format('svg');
    }
</style>