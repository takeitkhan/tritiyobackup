<style>
    @font-face {
        font-family: 'Glyphicons Halflings';
        src: url('http://www.tritiyo.com/schools/fonts/glyphicons-halflings-regular.eot');
        src: url('http://www.tritiyo.com/schools/fonts/glyphicons-halflings-regular.eot?#iefix') format('embedded-opentype'),
        url('http://www.tritiyo.com/schools/fonts/glyphicons-halflings-regular.woff2') format('woff2'),
        url('http://www.tritiyo.com/schools/fonts/glyphicons-halflings-regular.woff') format('woff'),
        url('http://www.tritiyo.com/schools/fonts/glyphicons-halflings-regular.ttf') format('truetype'),
        url('http://www.tritiyo.com/schools/fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular') format('svg');
    }
</style>