<li class="vn">
    <a><i class="fa fa-bar-chart-o"></i> Reports as Division Education Officer<span
            class="fa fa-chevron-down"></span></a>
    <ul style="display: none;" class="nav child_menu">
        <li><a href="<?php __menu("mystudents") ?>">My Students</a></li>
    </ul>
</li>