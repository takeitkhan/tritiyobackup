<div class="row mainbox">
    <table id="allresults" class="display" cellspacing="0" width="100%" class="table table-striped table-bordered">
        <thead>
        <tr>
            <th>ResultId</th>
            <th>Student</th>
            <th>Class</th>
            <th>Section</th>
            <th>Group</th>
            <th>Exam </th>
            <th>Subject</th>
            <th>Written</th>
            <th>MCQ</th>
            <th>Practical</th>
            <th>Speaking</th>
            <th>Reading</th>
            <th>Listening</th>
            <th>Created On</th>
            <th>Year</th>
            <th>Edit</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>ResultId</th>
            <th>Student</th>
            <th>Class</th>
            <th>Section</th>
            <th>Group</th>
            <th>Exam </th>
            <th>Subject</th>
            <th>Written</th>
            <th>MCQ</th>
            <th>Practical</th>
            <th>Speaking</th>
            <th>Reading</th>
            <th>Listening</th>
            <th>Created On</th>
            <th>Year</th>
            <th>Edit</th>
        </tr>
        </tfoot>
    </table>
</div>