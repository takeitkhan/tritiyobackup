<?php
	owndebugger($written);
?>