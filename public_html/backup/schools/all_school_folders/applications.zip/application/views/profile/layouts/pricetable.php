<div class="col-md-4 text-center">
    <div class="panel panel-success panel-pricing">
        <div class="panel-heading">
            <h3>FREEDOM VIRAL</h3>
        </div>
        <div class="panel-body text-center">
            <p><strong>$0 / Month</strong></p>
        </div>
        <div class="panel-footer">
            <a class="btn btn-block btn-default" href="#">ACTIVATED</a>
        </div>
    </div>
</div>
<div class="col-md-4 text-center">
    <div class="panel panel-default panel-pricing">
        <div class="panel-heading">
            <h3>TESLA</h3>
        </div>
        <div class="panel-body text-center">
            <p><strong>$19 / Month</strong></p>
        </div>
        <div class="panel-footer">
            <a class="btn  btn-block btn-success" href="#">UPGRADE NOW!</a>
        </div>
    </div>
</div>
<div class="col-md-4 text-center">
    <div class="panel panel-default panel-pricing">
        <div class="panel-heading">
            <h3>MOTHER TERESA</h3>
        </div>
        <div class="panel-body text-center">
            <p><strong>$49 / Month</strong></p>
        </div>
        <div class="panel-footer">
            <a class="btn  btn-block btn-success" href="#">UPGRADE NOW!</a>
        </div>
    </div>
</div>
<div class="col-md-4 text-center">
    <div class="panel panel-default panel-pricing">
        <div class="panel-heading">
            <h3>WORLD PEACE</h3>
        </div>
        <div class="panel-body text-center">
            <p><strong>$99 / Month</strong></p>
        </div>
        <div class="panel-footer">
            <a class="btn  btn-block btn-success" href="#">UPGRADE NOW!</a>
        </div>
    </div>
</div>
<div class="col-md-4 text-center">
    <div class="panel panel-default panel-pricing">
        <div class="panel-heading">
            <h3>EINSTEIN</h3>
        </div>
        <div class="panel-body text-center">
            <p><strong>$199 / Month</strong></p>
        </div>
        <div class="panel-footer">
            <a class="btn  btn-block btn-success" href="#">UPGRADE NOW!</a>
        </div>
    </div>
</div>
<div class="col-md-4 text-center">
    <div class="panel panel-default panel-pricing">
        <div class="panel-heading">
            <h3>WORLD CHANGER</h3>
        </div>
        <div class="panel-body text-center">
            <p><strong>$299 / Month</strong></p>
        </div>
        <div class="panel-footer">
            <a class="btn  btn-block btn-success" href="#">UPGRADE NOW!</a>
        </div>
    </div>
</div>