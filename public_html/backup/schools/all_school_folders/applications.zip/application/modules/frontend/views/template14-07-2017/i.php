<!DOCTYPE html>
<html class="google mmfb" itemscope itemtype="http://schema.org/Product" lang="bn">
<meta charset="utf-8">
<style>
center { font-family: kalpurush; font-size: 40px; color: red; margin-top: 50px; }
</style>
<title>Maintenance</title>
<body>
<center>সাইটটির রক্ষনাবেক্ষনের কাজ চলিতেছে। <br/>খুব শীগ্রই নতুন সফটওয়্যার আপলোড করা হবে। <br/>আশা করি খুব শীগ্রই সাইট অনলাইনে পাবেন। </center>
</body>
</html>