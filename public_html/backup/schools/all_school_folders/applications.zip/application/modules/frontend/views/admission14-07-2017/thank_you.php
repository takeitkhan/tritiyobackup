<div class="instructionPage">
    <div class="bfullpage">
        <div style="text-align: center; color: green; font-size: 24px; margin: 100px 0;">
            নিচে দেয়া নম্বরটি সংরক্ষণ করুন। পরবর্তী যে কোন স্টেটাস এর জন্য এই নম্বরটির প্রয়োজন হবে। ধন্যবাদ।
            <br/><br/><br/>
            <h1 style="text-align: center; color: red; font-size: 60px;"><?php __e($_GET['getrandomid']); ?></h1>
        </div>

    </div>
</div>