<?php $this->load->view('header'); ?>
<?php $this->load->view('content'); ?>
<?php $this->load->view('footer'); ?>