<?php
define('POWERSTART', 'http://' . $_SERVER['SERVER_NAME']); // domain name
define('HOSPITAL', 'localhost'); // no change
define('VISITOR', 'tritiyo_softu'); // database user
define('FINGER', 'A9x*P+.0roB#'); // database password
define('DOCTOR', 'tritiyo_nagbari'); // database name
?>