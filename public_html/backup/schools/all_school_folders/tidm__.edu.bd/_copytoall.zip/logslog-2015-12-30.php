<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-12-30 20:30:29 --> Config Class Initialized
INFO - 2015-12-30 20:30:29 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:30:29 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:30:29 --> Utf8 Class Initialized
INFO - 2015-12-30 20:30:29 --> URI Class Initialized
DEBUG - 2015-12-30 20:30:29 --> No URI present. Default controller set.
INFO - 2015-12-30 20:30:29 --> Router Class Initialized
INFO - 2015-12-30 20:30:29 --> Output Class Initialized
INFO - 2015-12-30 20:30:29 --> Security Class Initialized
DEBUG - 2015-12-30 20:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:30:29 --> Input Class Initialized
INFO - 2015-12-30 20:30:29 --> Language Class Initialized
INFO - 2015-12-30 20:30:29 --> Language Class Initialized
INFO - 2015-12-30 20:30:29 --> Config Class Initialized
INFO - 2015-12-30 20:30:29 --> Loader Class Initialized
INFO - 2015-12-30 20:30:29 --> Helper loaded: url_helper
INFO - 2015-12-30 20:30:29 --> Helper loaded: file_helper
INFO - 2015-12-30 20:30:29 --> Helper loaded: security_helper
INFO - 2015-12-30 20:30:29 --> Helper loaded: form_helper
INFO - 2015-12-30 20:30:29 --> Model Class Initialized
INFO - 2015-12-30 20:30:29 --> Model Class Initialized
INFO - 2015-12-30 20:30:29 --> Model Class Initialized
INFO - 2015-12-30 20:30:29 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:30:29 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:30:29 --> Helper loaded: language_helper
INFO - 2015-12-30 20:30:29 --> Database Driver Class Initialized
INFO - 2015-12-30 20:30:29 --> Email Class Initialized
ERROR - 2015-12-30 20:30:29 --> Query error: Table 'tritiyo_nagbari.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '621ab5eb48915bab909ecdc6e35f0da9a7a10fce'
INFO - 2015-12-30 20:30:29 --> Language file loaded: language/english/db_lang.php
INFO - 2015-12-30 20:36:42 --> Config Class Initialized
INFO - 2015-12-30 20:36:42 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:42 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:42 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:42 --> URI Class Initialized
DEBUG - 2015-12-30 20:36:42 --> No URI present. Default controller set.
INFO - 2015-12-30 20:36:42 --> Router Class Initialized
INFO - 2015-12-30 20:36:42 --> Output Class Initialized
INFO - 2015-12-30 20:36:42 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:42 --> Input Class Initialized
INFO - 2015-12-30 20:36:42 --> Language Class Initialized
INFO - 2015-12-30 20:36:42 --> Language Class Initialized
INFO - 2015-12-30 20:36:42 --> Config Class Initialized
INFO - 2015-12-30 20:36:42 --> Loader Class Initialized
INFO - 2015-12-30 20:36:42 --> Helper loaded: url_helper
INFO - 2015-12-30 20:36:42 --> Helper loaded: file_helper
INFO - 2015-12-30 20:36:42 --> Helper loaded: security_helper
INFO - 2015-12-30 20:36:42 --> Helper loaded: form_helper
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:36:42 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:36:42 --> Helper loaded: language_helper
INFO - 2015-12-30 20:36:42 --> Database Driver Class Initialized
INFO - 2015-12-30 20:36:42 --> Email Class Initialized
INFO - 2015-12-30 20:36:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:36:42 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:36:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:36:42 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Helper loaded: date_helper
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Controller Class Initialized
DEBUG - 2015-12-30 20:36:42 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:36:42 --> Model Class Initialized
INFO - 2015-12-30 20:36:42 --> Form Validation Class Initialized
INFO - 2015-12-30 20:36:42 --> Upload Class Initialized
DEBUG - 2015-12-30 20:36:42 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:36:42 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:36:42 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:36:42 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:36:42 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:36:42 --> Final output sent to browser
DEBUG - 2015-12-30 20:36:42 --> Total execution time: 0.1107
INFO - 2015-12-30 20:36:42 --> Config Class Initialized
INFO - 2015-12-30 20:36:42 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:42 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:42 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:42 --> URI Class Initialized
INFO - 2015-12-30 20:36:42 --> Router Class Initialized
INFO - 2015-12-30 20:36:42 --> Output Class Initialized
INFO - 2015-12-30 20:36:42 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:42 --> Input Class Initialized
INFO - 2015-12-30 20:36:42 --> Language Class Initialized
ERROR - 2015-12-30 20:36:42 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
INFO - 2015-12-30 20:36:43 --> Config Class Initialized
INFO - 2015-12-30 20:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:36:43 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:43 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:43 --> URI Class Initialized
INFO - 2015-12-30 20:36:43 --> Router Class Initialized
INFO - 2015-12-30 20:36:43 --> Output Class Initialized
INFO - 2015-12-30 20:36:43 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:43 --> Input Class Initialized
INFO - 2015-12-30 20:36:43 --> Language Class Initialized
ERROR - 2015-12-30 20:36:43 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:44 --> Config Class Initialized
INFO - 2015-12-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:44 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:44 --> URI Class Initialized
INFO - 2015-12-30 20:36:44 --> Router Class Initialized
INFO - 2015-12-30 20:36:44 --> Output Class Initialized
INFO - 2015-12-30 20:36:44 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:44 --> Input Class Initialized
INFO - 2015-12-30 20:36:44 --> Language Class Initialized
ERROR - 2015-12-30 20:36:44 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:44 --> Config Class Initialized
INFO - 2015-12-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:44 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:44 --> URI Class Initialized
INFO - 2015-12-30 20:36:44 --> Router Class Initialized
INFO - 2015-12-30 20:36:44 --> Output Class Initialized
INFO - 2015-12-30 20:36:44 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:44 --> Input Class Initialized
INFO - 2015-12-30 20:36:44 --> Language Class Initialized
ERROR - 2015-12-30 20:36:44 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:44 --> Config Class Initialized
INFO - 2015-12-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:44 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:44 --> URI Class Initialized
INFO - 2015-12-30 20:36:44 --> Router Class Initialized
INFO - 2015-12-30 20:36:44 --> Output Class Initialized
INFO - 2015-12-30 20:36:44 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:44 --> Input Class Initialized
INFO - 2015-12-30 20:36:44 --> Language Class Initialized
ERROR - 2015-12-30 20:36:44 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:44 --> Config Class Initialized
INFO - 2015-12-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:44 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:44 --> URI Class Initialized
INFO - 2015-12-30 20:36:44 --> Router Class Initialized
INFO - 2015-12-30 20:36:44 --> Output Class Initialized
INFO - 2015-12-30 20:36:44 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:44 --> Input Class Initialized
INFO - 2015-12-30 20:36:44 --> Language Class Initialized
ERROR - 2015-12-30 20:36:44 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:44 --> Config Class Initialized
INFO - 2015-12-30 20:36:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:44 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:44 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:44 --> URI Class Initialized
INFO - 2015-12-30 20:36:44 --> Router Class Initialized
INFO - 2015-12-30 20:36:44 --> Output Class Initialized
INFO - 2015-12-30 20:36:44 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:44 --> Input Class Initialized
INFO - 2015-12-30 20:36:44 --> Language Class Initialized
ERROR - 2015-12-30 20:36:44 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:46 --> Config Class Initialized
INFO - 2015-12-30 20:36:46 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:46 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:46 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:46 --> URI Class Initialized
INFO - 2015-12-30 20:36:46 --> Router Class Initialized
INFO - 2015-12-30 20:36:46 --> Output Class Initialized
INFO - 2015-12-30 20:36:46 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:46 --> Input Class Initialized
INFO - 2015-12-30 20:36:46 --> Language Class Initialized
ERROR - 2015-12-30 20:36:46 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:36:47 --> Config Class Initialized
INFO - 2015-12-30 20:36:47 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:36:47 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:36:47 --> Utf8 Class Initialized
INFO - 2015-12-30 20:36:47 --> URI Class Initialized
INFO - 2015-12-30 20:36:47 --> Router Class Initialized
INFO - 2015-12-30 20:36:47 --> Output Class Initialized
INFO - 2015-12-30 20:36:47 --> Security Class Initialized
DEBUG - 2015-12-30 20:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:36:47 --> Input Class Initialized
INFO - 2015-12-30 20:36:47 --> Language Class Initialized
ERROR - 2015-12-30 20:36:47 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:07 --> Config Class Initialized
INFO - 2015-12-30 20:39:07 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:07 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:07 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:07 --> URI Class Initialized
DEBUG - 2015-12-30 20:39:07 --> No URI present. Default controller set.
INFO - 2015-12-30 20:39:07 --> Router Class Initialized
INFO - 2015-12-30 20:39:07 --> Output Class Initialized
INFO - 2015-12-30 20:39:07 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:07 --> Input Class Initialized
INFO - 2015-12-30 20:39:07 --> Language Class Initialized
INFO - 2015-12-30 20:39:07 --> Language Class Initialized
INFO - 2015-12-30 20:39:07 --> Config Class Initialized
INFO - 2015-12-30 20:39:07 --> Loader Class Initialized
INFO - 2015-12-30 20:39:07 --> Helper loaded: url_helper
INFO - 2015-12-30 20:39:07 --> Helper loaded: file_helper
INFO - 2015-12-30 20:39:07 --> Helper loaded: security_helper
INFO - 2015-12-30 20:39:07 --> Helper loaded: form_helper
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:39:07 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:39:07 --> Helper loaded: language_helper
INFO - 2015-12-30 20:39:07 --> Database Driver Class Initialized
INFO - 2015-12-30 20:39:07 --> Email Class Initialized
INFO - 2015-12-30 20:39:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:39:07 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:39:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:39:07 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Helper loaded: date_helper
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Controller Class Initialized
DEBUG - 2015-12-30 20:39:07 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:39:07 --> Model Class Initialized
INFO - 2015-12-30 20:39:07 --> Form Validation Class Initialized
INFO - 2015-12-30 20:39:07 --> Upload Class Initialized
DEBUG - 2015-12-30 20:39:07 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:39:07 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:39:07 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:39:07 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:39:07 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:39:07 --> Final output sent to browser
DEBUG - 2015-12-30 20:39:07 --> Total execution time: 0.1123
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:08 --> Config Class Initialized
INFO - 2015-12-30 20:39:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:08 --> URI Class Initialized
INFO - 2015-12-30 20:39:08 --> Router Class Initialized
INFO - 2015-12-30 20:39:08 --> Output Class Initialized
INFO - 2015-12-30 20:39:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:08 --> Input Class Initialized
INFO - 2015-12-30 20:39:08 --> Language Class Initialized
ERROR - 2015-12-30 20:39:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:09 --> Config Class Initialized
INFO - 2015-12-30 20:39:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:09 --> URI Class Initialized
INFO - 2015-12-30 20:39:09 --> Router Class Initialized
INFO - 2015-12-30 20:39:09 --> Output Class Initialized
INFO - 2015-12-30 20:39:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:09 --> Input Class Initialized
INFO - 2015-12-30 20:39:09 --> Language Class Initialized
ERROR - 2015-12-30 20:39:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:10 --> Config Class Initialized
INFO - 2015-12-30 20:39:10 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:10 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:10 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:10 --> URI Class Initialized
INFO - 2015-12-30 20:39:10 --> Router Class Initialized
INFO - 2015-12-30 20:39:10 --> Output Class Initialized
INFO - 2015-12-30 20:39:10 --> Config Class Initialized
INFO - 2015-12-30 20:39:10 --> Hooks Class Initialized
INFO - 2015-12-30 20:39:10 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-12-30 20:39:10 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:10 --> Input Class Initialized
INFO - 2015-12-30 20:39:10 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:10 --> Language Class Initialized
INFO - 2015-12-30 20:39:10 --> URI Class Initialized
ERROR - 2015-12-30 20:39:10 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:10 --> Router Class Initialized
INFO - 2015-12-30 20:39:10 --> Output Class Initialized
INFO - 2015-12-30 20:39:10 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:10 --> Input Class Initialized
INFO - 2015-12-30 20:39:10 --> Language Class Initialized
ERROR - 2015-12-30 20:39:10 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:10 --> Config Class Initialized
INFO - 2015-12-30 20:39:10 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:10 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:10 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:10 --> URI Class Initialized
INFO - 2015-12-30 20:39:10 --> Router Class Initialized
INFO - 2015-12-30 20:39:10 --> Output Class Initialized
INFO - 2015-12-30 20:39:10 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:10 --> Input Class Initialized
INFO - 2015-12-30 20:39:10 --> Language Class Initialized
ERROR - 2015-12-30 20:39:10 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:10 --> Config Class Initialized
INFO - 2015-12-30 20:39:10 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:10 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:10 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:10 --> URI Class Initialized
INFO - 2015-12-30 20:39:10 --> Router Class Initialized
INFO - 2015-12-30 20:39:10 --> Output Class Initialized
INFO - 2015-12-30 20:39:10 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:10 --> Input Class Initialized
INFO - 2015-12-30 20:39:10 --> Language Class Initialized
ERROR - 2015-12-30 20:39:10 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:39:11 --> Config Class Initialized
INFO - 2015-12-30 20:39:11 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:11 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:11 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:11 --> URI Class Initialized
DEBUG - 2015-12-30 20:39:11 --> No URI present. Default controller set.
INFO - 2015-12-30 20:39:11 --> Router Class Initialized
INFO - 2015-12-30 20:39:11 --> Output Class Initialized
INFO - 2015-12-30 20:39:11 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:11 --> Input Class Initialized
INFO - 2015-12-30 20:39:11 --> Language Class Initialized
INFO - 2015-12-30 20:39:11 --> Language Class Initialized
INFO - 2015-12-30 20:39:11 --> Config Class Initialized
INFO - 2015-12-30 20:39:11 --> Loader Class Initialized
INFO - 2015-12-30 20:39:11 --> Helper loaded: url_helper
INFO - 2015-12-30 20:39:11 --> Helper loaded: file_helper
INFO - 2015-12-30 20:39:11 --> Helper loaded: security_helper
INFO - 2015-12-30 20:39:11 --> Helper loaded: form_helper
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:39:11 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:39:11 --> Helper loaded: language_helper
INFO - 2015-12-30 20:39:11 --> Database Driver Class Initialized
INFO - 2015-12-30 20:39:11 --> Email Class Initialized
INFO - 2015-12-30 20:39:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:39:11 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:39:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:39:11 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Helper loaded: date_helper
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Controller Class Initialized
DEBUG - 2015-12-30 20:39:11 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:39:11 --> Model Class Initialized
INFO - 2015-12-30 20:39:11 --> Form Validation Class Initialized
INFO - 2015-12-30 20:39:11 --> Upload Class Initialized
DEBUG - 2015-12-30 20:39:11 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:39:11 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:39:11 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:39:11 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:39:11 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:39:11 --> Final output sent to browser
DEBUG - 2015-12-30 20:39:11 --> Total execution time: 0.1090
INFO - 2015-12-30 20:39:54 --> Config Class Initialized
INFO - 2015-12-30 20:39:54 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:39:54 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:39:54 --> Utf8 Class Initialized
INFO - 2015-12-30 20:39:54 --> URI Class Initialized
DEBUG - 2015-12-30 20:39:54 --> No URI present. Default controller set.
INFO - 2015-12-30 20:39:54 --> Router Class Initialized
INFO - 2015-12-30 20:39:54 --> Output Class Initialized
INFO - 2015-12-30 20:39:54 --> Security Class Initialized
DEBUG - 2015-12-30 20:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:39:54 --> Input Class Initialized
INFO - 2015-12-30 20:39:54 --> Language Class Initialized
INFO - 2015-12-30 20:39:54 --> Language Class Initialized
INFO - 2015-12-30 20:39:54 --> Config Class Initialized
INFO - 2015-12-30 20:39:54 --> Loader Class Initialized
INFO - 2015-12-30 20:39:54 --> Helper loaded: url_helper
INFO - 2015-12-30 20:39:54 --> Helper loaded: file_helper
INFO - 2015-12-30 20:39:54 --> Helper loaded: security_helper
INFO - 2015-12-30 20:39:54 --> Helper loaded: form_helper
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:39:54 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:39:54 --> Helper loaded: language_helper
INFO - 2015-12-30 20:39:54 --> Database Driver Class Initialized
INFO - 2015-12-30 20:39:54 --> Email Class Initialized
INFO - 2015-12-30 20:39:54 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:39:54 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:39:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:39:54 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Helper loaded: date_helper
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Controller Class Initialized
DEBUG - 2015-12-30 20:39:54 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:39:54 --> Model Class Initialized
INFO - 2015-12-30 20:39:54 --> Form Validation Class Initialized
INFO - 2015-12-30 20:39:54 --> Upload Class Initialized
DEBUG - 2015-12-30 20:39:54 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:39:54 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:39:54 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:39:54 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:39:54 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:39:54 --> Final output sent to browser
DEBUG - 2015-12-30 20:39:54 --> Total execution time: 0.0922
INFO - 2015-12-30 20:40:01 --> Config Class Initialized
INFO - 2015-12-30 20:40:01 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:01 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:01 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:01 --> URI Class Initialized
DEBUG - 2015-12-30 20:40:01 --> No URI present. Default controller set.
INFO - 2015-12-30 20:40:01 --> Router Class Initialized
INFO - 2015-12-30 20:40:01 --> Output Class Initialized
INFO - 2015-12-30 20:40:01 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:01 --> Input Class Initialized
INFO - 2015-12-30 20:40:01 --> Language Class Initialized
INFO - 2015-12-30 20:40:01 --> Language Class Initialized
INFO - 2015-12-30 20:40:01 --> Config Class Initialized
INFO - 2015-12-30 20:40:01 --> Loader Class Initialized
INFO - 2015-12-30 20:40:01 --> Helper loaded: url_helper
INFO - 2015-12-30 20:40:01 --> Helper loaded: file_helper
INFO - 2015-12-30 20:40:01 --> Helper loaded: security_helper
INFO - 2015-12-30 20:40:01 --> Helper loaded: form_helper
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:40:01 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:40:01 --> Helper loaded: language_helper
INFO - 2015-12-30 20:40:01 --> Database Driver Class Initialized
INFO - 2015-12-30 20:40:01 --> Email Class Initialized
INFO - 2015-12-30 20:40:01 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:40:01 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:40:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:40:01 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Helper loaded: date_helper
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Controller Class Initialized
DEBUG - 2015-12-30 20:40:01 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:40:01 --> Model Class Initialized
INFO - 2015-12-30 20:40:01 --> Form Validation Class Initialized
INFO - 2015-12-30 20:40:01 --> Upload Class Initialized
DEBUG - 2015-12-30 20:40:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:40:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:40:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:40:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:40:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:40:01 --> Final output sent to browser
DEBUG - 2015-12-30 20:40:01 --> Total execution time: 0.1766
INFO - 2015-12-30 20:40:04 --> Config Class Initialized
INFO - 2015-12-30 20:40:04 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:04 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:04 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:04 --> URI Class Initialized
DEBUG - 2015-12-30 20:40:04 --> No URI present. Default controller set.
INFO - 2015-12-30 20:40:04 --> Router Class Initialized
INFO - 2015-12-30 20:40:04 --> Output Class Initialized
INFO - 2015-12-30 20:40:04 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:04 --> Input Class Initialized
INFO - 2015-12-30 20:40:04 --> Language Class Initialized
INFO - 2015-12-30 20:40:04 --> Language Class Initialized
INFO - 2015-12-30 20:40:04 --> Config Class Initialized
INFO - 2015-12-30 20:40:04 --> Loader Class Initialized
INFO - 2015-12-30 20:40:04 --> Helper loaded: url_helper
INFO - 2015-12-30 20:40:04 --> Helper loaded: file_helper
INFO - 2015-12-30 20:40:04 --> Helper loaded: security_helper
INFO - 2015-12-30 20:40:04 --> Helper loaded: form_helper
INFO - 2015-12-30 20:40:04 --> Model Class Initialized
INFO - 2015-12-30 20:40:04 --> Model Class Initialized
INFO - 2015-12-30 20:40:04 --> Model Class Initialized
INFO - 2015-12-30 20:40:04 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:40:04 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:40:04 --> Helper loaded: language_helper
INFO - 2015-12-30 20:40:04 --> Database Driver Class Initialized
INFO - 2015-12-30 20:40:04 --> Email Class Initialized
INFO - 2015-12-30 20:40:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:40:04 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:40:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:40:04 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:40:04 --> Model Class Initialized
INFO - 2015-12-30 20:40:05 --> Helper loaded: date_helper
INFO - 2015-12-30 20:40:05 --> Model Class Initialized
INFO - 2015-12-30 20:40:05 --> Model Class Initialized
INFO - 2015-12-30 20:40:05 --> Model Class Initialized
INFO - 2015-12-30 20:40:05 --> Model Class Initialized
INFO - 2015-12-30 20:40:05 --> Controller Class Initialized
DEBUG - 2015-12-30 20:40:05 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:40:05 --> Model Class Initialized
INFO - 2015-12-30 20:40:05 --> Form Validation Class Initialized
INFO - 2015-12-30 20:40:05 --> Upload Class Initialized
DEBUG - 2015-12-30 20:40:05 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:40:05 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:40:05 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:40:05 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:40:05 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:40:05 --> Final output sent to browser
DEBUG - 2015-12-30 20:40:05 --> Total execution time: 1.2019
INFO - 2015-12-30 20:40:06 --> Config Class Initialized
INFO - 2015-12-30 20:40:06 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:06 --> Config Class Initialized
INFO - 2015-12-30 20:40:06 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:06 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:06 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:06 --> Config Class Initialized
INFO - 2015-12-30 20:40:06 --> Config Class Initialized
INFO - 2015-12-30 20:40:06 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:06 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:06 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:06 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:06 --> URI Class Initialized
DEBUG - 2015-12-30 20:40:06 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:06 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:40:06 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:06 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:06 --> URI Class Initialized
INFO - 2015-12-30 20:40:06 --> URI Class Initialized
INFO - 2015-12-30 20:40:06 --> Config Class Initialized
INFO - 2015-12-30 20:40:06 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:06 --> Router Class Initialized
INFO - 2015-12-30 20:40:06 --> Config Class Initialized
INFO - 2015-12-30 20:40:06 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:06 --> Router Class Initialized
INFO - 2015-12-30 20:40:06 --> Output Class Initialized
DEBUG - 2015-12-30 20:40:06 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:06 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:06 --> Security Class Initialized
INFO - 2015-12-30 20:40:06 --> Output Class Initialized
DEBUG - 2015-12-30 20:40:06 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:06 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:06 --> Input Class Initialized
INFO - 2015-12-30 20:40:06 --> Security Class Initialized
INFO - 2015-12-30 20:40:06 --> URI Class Initialized
INFO - 2015-12-30 20:40:06 --> Language Class Initialized
ERROR - 2015-12-30 20:40:06 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:06 --> Input Class Initialized
INFO - 2015-12-30 20:40:06 --> Language Class Initialized
ERROR - 2015-12-30 20:40:06 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:06 --> URI Class Initialized
INFO - 2015-12-30 20:40:06 --> URI Class Initialized
INFO - 2015-12-30 20:40:06 --> Router Class Initialized
INFO - 2015-12-30 20:40:06 --> Output Class Initialized
INFO - 2015-12-30 20:40:06 --> Router Class Initialized
INFO - 2015-12-30 20:40:06 --> Security Class Initialized
INFO - 2015-12-30 20:40:06 --> Router Class Initialized
INFO - 2015-12-30 20:40:06 --> Router Class Initialized
DEBUG - 2015-12-30 20:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:06 --> Input Class Initialized
INFO - 2015-12-30 20:40:06 --> Output Class Initialized
INFO - 2015-12-30 20:40:06 --> Output Class Initialized
INFO - 2015-12-30 20:40:06 --> Language Class Initialized
INFO - 2015-12-30 20:40:06 --> Output Class Initialized
ERROR - 2015-12-30 20:40:06 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:06 --> Security Class Initialized
INFO - 2015-12-30 20:40:06 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:06 --> Input Class Initialized
INFO - 2015-12-30 20:40:06 --> Language Class Initialized
DEBUG - 2015-12-30 20:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:06 --> Input Class Initialized
INFO - 2015-12-30 20:40:06 --> Language Class Initialized
ERROR - 2015-12-30 20:40:06 --> 404 Page Not Found: /index
ERROR - 2015-12-30 20:40:06 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:06 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:06 --> Input Class Initialized
INFO - 2015-12-30 20:40:06 --> Language Class Initialized
ERROR - 2015-12-30 20:40:06 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:07 --> Config Class Initialized
INFO - 2015-12-30 20:40:07 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:07 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:07 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:07 --> URI Class Initialized
INFO - 2015-12-30 20:40:07 --> Router Class Initialized
INFO - 2015-12-30 20:40:07 --> Output Class Initialized
INFO - 2015-12-30 20:40:07 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:07 --> Input Class Initialized
INFO - 2015-12-30 20:40:07 --> Language Class Initialized
ERROR - 2015-12-30 20:40:07 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:07 --> Config Class Initialized
INFO - 2015-12-30 20:40:07 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:07 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:07 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:07 --> URI Class Initialized
INFO - 2015-12-30 20:40:07 --> Config Class Initialized
INFO - 2015-12-30 20:40:07 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:07 --> Router Class Initialized
DEBUG - 2015-12-30 20:40:07 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:07 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:07 --> Output Class Initialized
INFO - 2015-12-30 20:40:07 --> URI Class Initialized
INFO - 2015-12-30 20:40:07 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:07 --> Input Class Initialized
INFO - 2015-12-30 20:40:07 --> Language Class Initialized
ERROR - 2015-12-30 20:40:07 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:07 --> Router Class Initialized
INFO - 2015-12-30 20:40:07 --> Output Class Initialized
INFO - 2015-12-30 20:40:07 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:07 --> Input Class Initialized
INFO - 2015-12-30 20:40:07 --> Language Class Initialized
INFO - 2015-12-30 20:40:07 --> Config Class Initialized
INFO - 2015-12-30 20:40:07 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:07 --> Config Class Initialized
ERROR - 2015-12-30 20:40:07 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:07 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:07 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:07 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:40:07 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:07 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:07 --> URI Class Initialized
INFO - 2015-12-30 20:40:07 --> URI Class Initialized
INFO - 2015-12-30 20:40:07 --> Router Class Initialized
INFO - 2015-12-30 20:40:07 --> Router Class Initialized
INFO - 2015-12-30 20:40:07 --> Output Class Initialized
INFO - 2015-12-30 20:40:07 --> Output Class Initialized
INFO - 2015-12-30 20:40:07 --> Security Class Initialized
INFO - 2015-12-30 20:40:07 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:07 --> Input Class Initialized
DEBUG - 2015-12-30 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:07 --> Input Class Initialized
INFO - 2015-12-30 20:40:07 --> Language Class Initialized
INFO - 2015-12-30 20:40:07 --> Language Class Initialized
ERROR - 2015-12-30 20:40:07 --> 404 Page Not Found: /index
ERROR - 2015-12-30 20:40:07 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
INFO - 2015-12-30 20:40:08 --> Config Class Initialized
INFO - 2015-12-30 20:40:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:40:08 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:08 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
INFO - 2015-12-30 20:40:08 --> URI Class Initialized
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
INFO - 2015-12-30 20:40:08 --> Router Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:08 --> Output Class Initialized
INFO - 2015-12-30 20:40:08 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:08 --> Input Class Initialized
INFO - 2015-12-30 20:40:08 --> Language Class Initialized
ERROR - 2015-12-30 20:40:08 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:09 --> Config Class Initialized
INFO - 2015-12-30 20:40:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:09 --> URI Class Initialized
INFO - 2015-12-30 20:40:09 --> Router Class Initialized
INFO - 2015-12-30 20:40:09 --> Output Class Initialized
INFO - 2015-12-30 20:40:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:09 --> Input Class Initialized
INFO - 2015-12-30 20:40:09 --> Language Class Initialized
ERROR - 2015-12-30 20:40:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:09 --> Config Class Initialized
INFO - 2015-12-30 20:40:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:09 --> URI Class Initialized
INFO - 2015-12-30 20:40:09 --> Router Class Initialized
INFO - 2015-12-30 20:40:09 --> Output Class Initialized
INFO - 2015-12-30 20:40:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:09 --> Input Class Initialized
INFO - 2015-12-30 20:40:09 --> Language Class Initialized
ERROR - 2015-12-30 20:40:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:09 --> Config Class Initialized
INFO - 2015-12-30 20:40:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:09 --> URI Class Initialized
INFO - 2015-12-30 20:40:09 --> Router Class Initialized
INFO - 2015-12-30 20:40:09 --> Output Class Initialized
INFO - 2015-12-30 20:40:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:09 --> Input Class Initialized
INFO - 2015-12-30 20:40:09 --> Language Class Initialized
ERROR - 2015-12-30 20:40:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:09 --> Config Class Initialized
INFO - 2015-12-30 20:40:09 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:09 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:09 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:09 --> URI Class Initialized
INFO - 2015-12-30 20:40:09 --> Router Class Initialized
INFO - 2015-12-30 20:40:09 --> Output Class Initialized
INFO - 2015-12-30 20:40:09 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:09 --> Input Class Initialized
INFO - 2015-12-30 20:40:09 --> Language Class Initialized
ERROR - 2015-12-30 20:40:09 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:40:19 --> Config Class Initialized
INFO - 2015-12-30 20:40:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:40:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:40:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:40:19 --> URI Class Initialized
DEBUG - 2015-12-30 20:40:19 --> No URI present. Default controller set.
INFO - 2015-12-30 20:40:19 --> Router Class Initialized
INFO - 2015-12-30 20:40:19 --> Output Class Initialized
INFO - 2015-12-30 20:40:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:40:19 --> Input Class Initialized
INFO - 2015-12-30 20:40:19 --> Language Class Initialized
INFO - 2015-12-30 20:40:19 --> Language Class Initialized
INFO - 2015-12-30 20:40:19 --> Config Class Initialized
INFO - 2015-12-30 20:40:19 --> Loader Class Initialized
INFO - 2015-12-30 20:40:19 --> Helper loaded: url_helper
INFO - 2015-12-30 20:40:19 --> Helper loaded: file_helper
INFO - 2015-12-30 20:40:19 --> Helper loaded: security_helper
INFO - 2015-12-30 20:40:19 --> Helper loaded: form_helper
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:40:19 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:40:19 --> Helper loaded: language_helper
INFO - 2015-12-30 20:40:19 --> Database Driver Class Initialized
INFO - 2015-12-30 20:40:19 --> Email Class Initialized
INFO - 2015-12-30 20:40:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:40:19 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:40:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:40:19 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Helper loaded: date_helper
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Controller Class Initialized
DEBUG - 2015-12-30 20:40:19 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:40:19 --> Model Class Initialized
INFO - 2015-12-30 20:40:19 --> Form Validation Class Initialized
INFO - 2015-12-30 20:40:19 --> Upload Class Initialized
DEBUG - 2015-12-30 20:40:19 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:40:19 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:40:19 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:40:19 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:40:19 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:40:19 --> Final output sent to browser
DEBUG - 2015-12-30 20:40:19 --> Total execution time: 0.1002
INFO - 2015-12-30 20:44:25 --> Config Class Initialized
INFO - 2015-12-30 20:44:25 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:25 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:25 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:25 --> URI Class Initialized
DEBUG - 2015-12-30 20:44:25 --> No URI present. Default controller set.
INFO - 2015-12-30 20:44:25 --> Router Class Initialized
INFO - 2015-12-30 20:44:25 --> Output Class Initialized
INFO - 2015-12-30 20:44:25 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:25 --> Input Class Initialized
INFO - 2015-12-30 20:44:25 --> Language Class Initialized
INFO - 2015-12-30 20:44:25 --> Language Class Initialized
INFO - 2015-12-30 20:44:25 --> Config Class Initialized
INFO - 2015-12-30 20:44:25 --> Loader Class Initialized
INFO - 2015-12-30 20:44:25 --> Helper loaded: url_helper
INFO - 2015-12-30 20:44:25 --> Helper loaded: file_helper
INFO - 2015-12-30 20:44:25 --> Helper loaded: security_helper
INFO - 2015-12-30 20:44:25 --> Helper loaded: form_helper
INFO - 2015-12-30 20:44:25 --> Model Class Initialized
INFO - 2015-12-30 20:44:25 --> Model Class Initialized
INFO - 2015-12-30 20:44:25 --> Model Class Initialized
INFO - 2015-12-30 20:44:25 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:44:25 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:44:25 --> Helper loaded: language_helper
INFO - 2015-12-30 20:44:25 --> Database Driver Class Initialized
INFO - 2015-12-30 20:44:25 --> Email Class Initialized
INFO - 2015-12-30 20:44:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:44:25 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:44:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:44:25 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:44:25 --> Model Class Initialized
INFO - 2015-12-30 20:44:25 --> Helper loaded: date_helper
INFO - 2015-12-30 20:44:26 --> Model Class Initialized
INFO - 2015-12-30 20:44:26 --> Model Class Initialized
INFO - 2015-12-30 20:44:26 --> Model Class Initialized
INFO - 2015-12-30 20:44:26 --> Model Class Initialized
INFO - 2015-12-30 20:44:26 --> Controller Class Initialized
DEBUG - 2015-12-30 20:44:26 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:44:26 --> Model Class Initialized
INFO - 2015-12-30 20:44:26 --> Form Validation Class Initialized
INFO - 2015-12-30 20:44:26 --> Upload Class Initialized
DEBUG - 2015-12-30 20:44:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:44:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:44:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:44:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:44:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:44:26 --> Final output sent to browser
DEBUG - 2015-12-30 20:44:26 --> Total execution time: 0.0968
INFO - 2015-12-30 20:44:26 --> Config Class Initialized
INFO - 2015-12-30 20:44:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:26 --> URI Class Initialized
INFO - 2015-12-30 20:44:26 --> Router Class Initialized
INFO - 2015-12-30 20:44:26 --> Output Class Initialized
INFO - 2015-12-30 20:44:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:26 --> Input Class Initialized
INFO - 2015-12-30 20:44:26 --> Language Class Initialized
ERROR - 2015-12-30 20:44:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:26 --> Config Class Initialized
INFO - 2015-12-30 20:44:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:26 --> Config Class Initialized
INFO - 2015-12-30 20:44:26 --> Hooks Class Initialized
INFO - 2015-12-30 20:44:26 --> URI Class Initialized
DEBUG - 2015-12-30 20:44:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:26 --> URI Class Initialized
INFO - 2015-12-30 20:44:26 --> Router Class Initialized
INFO - 2015-12-30 20:44:26 --> Output Class Initialized
INFO - 2015-12-30 20:44:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:26 --> Input Class Initialized
INFO - 2015-12-30 20:44:26 --> Language Class Initialized
INFO - 2015-12-30 20:44:26 --> Router Class Initialized
ERROR - 2015-12-30 20:44:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:26 --> Output Class Initialized
INFO - 2015-12-30 20:44:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:26 --> Input Class Initialized
INFO - 2015-12-30 20:44:26 --> Language Class Initialized
ERROR - 2015-12-30 20:44:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:26 --> Config Class Initialized
INFO - 2015-12-30 20:44:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:26 --> Config Class Initialized
INFO - 2015-12-30 20:44:26 --> Hooks Class Initialized
INFO - 2015-12-30 20:44:26 --> URI Class Initialized
DEBUG - 2015-12-30 20:44:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:26 --> URI Class Initialized
INFO - 2015-12-30 20:44:26 --> Router Class Initialized
INFO - 2015-12-30 20:44:26 --> Router Class Initialized
INFO - 2015-12-30 20:44:26 --> Output Class Initialized
INFO - 2015-12-30 20:44:26 --> Output Class Initialized
INFO - 2015-12-30 20:44:26 --> Security Class Initialized
INFO - 2015-12-30 20:44:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:26 --> Config Class Initialized
INFO - 2015-12-30 20:44:26 --> Input Class Initialized
INFO - 2015-12-30 20:44:26 --> Hooks Class Initialized
INFO - 2015-12-30 20:44:26 --> Language Class Initialized
ERROR - 2015-12-30 20:44:26 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:26 --> Input Class Initialized
INFO - 2015-12-30 20:44:26 --> Language Class Initialized
DEBUG - 2015-12-30 20:44:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:26 --> Utf8 Class Initialized
ERROR - 2015-12-30 20:44:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:26 --> URI Class Initialized
INFO - 2015-12-30 20:44:26 --> Router Class Initialized
INFO - 2015-12-30 20:44:26 --> Output Class Initialized
INFO - 2015-12-30 20:44:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:26 --> Input Class Initialized
INFO - 2015-12-30 20:44:26 --> Language Class Initialized
ERROR - 2015-12-30 20:44:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:26 --> Config Class Initialized
INFO - 2015-12-30 20:44:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:26 --> URI Class Initialized
INFO - 2015-12-30 20:44:26 --> Router Class Initialized
INFO - 2015-12-30 20:44:26 --> Output Class Initialized
INFO - 2015-12-30 20:44:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:27 --> Input Class Initialized
INFO - 2015-12-30 20:44:27 --> Language Class Initialized
ERROR - 2015-12-30 20:44:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:27 --> Config Class Initialized
INFO - 2015-12-30 20:44:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:27 --> URI Class Initialized
INFO - 2015-12-30 20:44:27 --> Router Class Initialized
INFO - 2015-12-30 20:44:27 --> Output Class Initialized
INFO - 2015-12-30 20:44:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:27 --> Input Class Initialized
INFO - 2015-12-30 20:44:27 --> Language Class Initialized
ERROR - 2015-12-30 20:44:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:27 --> Config Class Initialized
INFO - 2015-12-30 20:44:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:27 --> URI Class Initialized
INFO - 2015-12-30 20:44:27 --> Config Class Initialized
INFO - 2015-12-30 20:44:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:27 --> Router Class Initialized
INFO - 2015-12-30 20:44:27 --> URI Class Initialized
INFO - 2015-12-30 20:44:27 --> Output Class Initialized
INFO - 2015-12-30 20:44:27 --> Security Class Initialized
INFO - 2015-12-30 20:44:27 --> Router Class Initialized
DEBUG - 2015-12-30 20:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:27 --> Input Class Initialized
INFO - 2015-12-30 20:44:27 --> Language Class Initialized
INFO - 2015-12-30 20:44:27 --> Output Class Initialized
ERROR - 2015-12-30 20:44:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:27 --> Security Class Initialized
INFO - 2015-12-30 20:44:27 --> Config Class Initialized
INFO - 2015-12-30 20:44:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:27 --> Input Class Initialized
INFO - 2015-12-30 20:44:27 --> Language Class Initialized
ERROR - 2015-12-30 20:44:27 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:44:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:27 --> URI Class Initialized
INFO - 2015-12-30 20:44:27 --> Router Class Initialized
INFO - 2015-12-30 20:44:27 --> Output Class Initialized
INFO - 2015-12-30 20:44:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:27 --> Input Class Initialized
INFO - 2015-12-30 20:44:27 --> Language Class Initialized
ERROR - 2015-12-30 20:44:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:28 --> Config Class Initialized
INFO - 2015-12-30 20:44:28 --> Hooks Class Initialized
INFO - 2015-12-30 20:44:28 --> Config Class Initialized
INFO - 2015-12-30 20:44:28 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:28 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:44:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:28 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:28 --> URI Class Initialized
INFO - 2015-12-30 20:44:28 --> URI Class Initialized
INFO - 2015-12-30 20:44:28 --> Config Class Initialized
INFO - 2015-12-30 20:44:28 --> Hooks Class Initialized
INFO - 2015-12-30 20:44:28 --> Router Class Initialized
DEBUG - 2015-12-30 20:44:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:28 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:28 --> Output Class Initialized
INFO - 2015-12-30 20:44:28 --> Security Class Initialized
INFO - 2015-12-30 20:44:28 --> URI Class Initialized
INFO - 2015-12-30 20:44:28 --> Router Class Initialized
DEBUG - 2015-12-30 20:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:28 --> Input Class Initialized
INFO - 2015-12-30 20:44:28 --> Language Class Initialized
ERROR - 2015-12-30 20:44:28 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:28 --> Output Class Initialized
INFO - 2015-12-30 20:44:28 --> Security Class Initialized
INFO - 2015-12-30 20:44:28 --> Router Class Initialized
DEBUG - 2015-12-30 20:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:28 --> Input Class Initialized
INFO - 2015-12-30 20:44:28 --> Language Class Initialized
INFO - 2015-12-30 20:44:28 --> Output Class Initialized
ERROR - 2015-12-30 20:44:28 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:28 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:28 --> Input Class Initialized
INFO - 2015-12-30 20:44:28 --> Language Class Initialized
ERROR - 2015-12-30 20:44:28 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:44:28 --> Config Class Initialized
INFO - 2015-12-30 20:44:28 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:44:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:44:28 --> Utf8 Class Initialized
INFO - 2015-12-30 20:44:28 --> URI Class Initialized
INFO - 2015-12-30 20:44:28 --> Router Class Initialized
INFO - 2015-12-30 20:44:28 --> Output Class Initialized
INFO - 2015-12-30 20:44:28 --> Security Class Initialized
DEBUG - 2015-12-30 20:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:44:28 --> Input Class Initialized
INFO - 2015-12-30 20:44:28 --> Language Class Initialized
ERROR - 2015-12-30 20:44:28 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:46:49 --> Config Class Initialized
INFO - 2015-12-30 20:46:49 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:49 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:49 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:49 --> URI Class Initialized
DEBUG - 2015-12-30 20:46:49 --> No URI present. Default controller set.
INFO - 2015-12-30 20:46:49 --> Router Class Initialized
INFO - 2015-12-30 20:46:49 --> Output Class Initialized
INFO - 2015-12-30 20:46:49 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:49 --> Input Class Initialized
INFO - 2015-12-30 20:46:49 --> Language Class Initialized
INFO - 2015-12-30 20:46:49 --> Language Class Initialized
INFO - 2015-12-30 20:46:49 --> Config Class Initialized
INFO - 2015-12-30 20:46:49 --> Loader Class Initialized
INFO - 2015-12-30 20:46:49 --> Helper loaded: url_helper
INFO - 2015-12-30 20:46:49 --> Helper loaded: file_helper
INFO - 2015-12-30 20:46:49 --> Helper loaded: security_helper
INFO - 2015-12-30 20:46:49 --> Helper loaded: form_helper
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:46:49 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:46:49 --> Helper loaded: language_helper
INFO - 2015-12-30 20:46:49 --> Database Driver Class Initialized
INFO - 2015-12-30 20:46:49 --> Email Class Initialized
INFO - 2015-12-30 20:46:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:46:49 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:46:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:46:49 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Helper loaded: date_helper
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Controller Class Initialized
DEBUG - 2015-12-30 20:46:49 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:46:49 --> Model Class Initialized
INFO - 2015-12-30 20:46:49 --> Form Validation Class Initialized
INFO - 2015-12-30 20:46:49 --> Upload Class Initialized
DEBUG - 2015-12-30 20:46:49 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:46:49 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:46:49 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:46:49 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:46:49 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:46:49 --> Final output sent to browser
DEBUG - 2015-12-30 20:46:49 --> Total execution time: 0.0941
INFO - 2015-12-30 20:46:50 --> Config Class Initialized
INFO - 2015-12-30 20:46:50 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:50 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:50 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:50 --> URI Class Initialized
INFO - 2015-12-30 20:46:50 --> Router Class Initialized
INFO - 2015-12-30 20:46:50 --> Output Class Initialized
INFO - 2015-12-30 20:46:50 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:50 --> Input Class Initialized
INFO - 2015-12-30 20:46:50 --> Language Class Initialized
ERROR - 2015-12-30 20:46:50 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:46:51 --> Config Class Initialized
INFO - 2015-12-30 20:46:51 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:51 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:51 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:51 --> URI Class Initialized
INFO - 2015-12-30 20:46:51 --> Router Class Initialized
INFO - 2015-12-30 20:46:51 --> Output Class Initialized
INFO - 2015-12-30 20:46:51 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:51 --> Input Class Initialized
INFO - 2015-12-30 20:46:51 --> Language Class Initialized
ERROR - 2015-12-30 20:46:51 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:46:51 --> Config Class Initialized
INFO - 2015-12-30 20:46:51 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:51 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:51 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:51 --> URI Class Initialized
INFO - 2015-12-30 20:46:51 --> Router Class Initialized
INFO - 2015-12-30 20:46:51 --> Output Class Initialized
INFO - 2015-12-30 20:46:51 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:51 --> Input Class Initialized
INFO - 2015-12-30 20:46:51 --> Language Class Initialized
ERROR - 2015-12-30 20:46:51 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:46:51 --> Config Class Initialized
INFO - 2015-12-30 20:46:51 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:51 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:51 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:51 --> URI Class Initialized
INFO - 2015-12-30 20:46:51 --> Router Class Initialized
INFO - 2015-12-30 20:46:51 --> Output Class Initialized
INFO - 2015-12-30 20:46:51 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:51 --> Input Class Initialized
INFO - 2015-12-30 20:46:51 --> Language Class Initialized
ERROR - 2015-12-30 20:46:51 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:46:52 --> Config Class Initialized
INFO - 2015-12-30 20:46:52 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:52 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:52 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:52 --> URI Class Initialized
INFO - 2015-12-30 20:46:52 --> Router Class Initialized
INFO - 2015-12-30 20:46:52 --> Output Class Initialized
INFO - 2015-12-30 20:46:52 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:52 --> Input Class Initialized
INFO - 2015-12-30 20:46:52 --> Language Class Initialized
ERROR - 2015-12-30 20:46:52 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:46:53 --> Config Class Initialized
INFO - 2015-12-30 20:46:53 --> Hooks Class Initialized
INFO - 2015-12-30 20:46:53 --> Config Class Initialized
INFO - 2015-12-30 20:46:53 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:53 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:53 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:46:53 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:53 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:53 --> URI Class Initialized
INFO - 2015-12-30 20:46:53 --> URI Class Initialized
INFO - 2015-12-30 20:46:53 --> Router Class Initialized
INFO - 2015-12-30 20:46:53 --> Router Class Initialized
INFO - 2015-12-30 20:46:53 --> Output Class Initialized
INFO - 2015-12-30 20:46:53 --> Output Class Initialized
INFO - 2015-12-30 20:46:53 --> Security Class Initialized
INFO - 2015-12-30 20:46:53 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:53 --> Input Class Initialized
DEBUG - 2015-12-30 20:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:53 --> Input Class Initialized
INFO - 2015-12-30 20:46:53 --> Language Class Initialized
INFO - 2015-12-30 20:46:53 --> Language Class Initialized
ERROR - 2015-12-30 20:46:53 --> 404 Page Not Found: /index
ERROR - 2015-12-30 20:46:53 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:46:53 --> Config Class Initialized
INFO - 2015-12-30 20:46:53 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:46:53 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:46:53 --> Utf8 Class Initialized
INFO - 2015-12-30 20:46:53 --> URI Class Initialized
INFO - 2015-12-30 20:46:53 --> Router Class Initialized
INFO - 2015-12-30 20:46:53 --> Output Class Initialized
INFO - 2015-12-30 20:46:53 --> Security Class Initialized
DEBUG - 2015-12-30 20:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:46:53 --> Input Class Initialized
INFO - 2015-12-30 20:46:53 --> Language Class Initialized
ERROR - 2015-12-30 20:46:53 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:01 --> Config Class Initialized
INFO - 2015-12-30 20:50:01 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:01 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:01 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:01 --> URI Class Initialized
DEBUG - 2015-12-30 20:50:01 --> No URI present. Default controller set.
INFO - 2015-12-30 20:50:01 --> Router Class Initialized
INFO - 2015-12-30 20:50:01 --> Output Class Initialized
INFO - 2015-12-30 20:50:01 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:01 --> Input Class Initialized
INFO - 2015-12-30 20:50:01 --> Language Class Initialized
INFO - 2015-12-30 20:50:01 --> Language Class Initialized
INFO - 2015-12-30 20:50:01 --> Config Class Initialized
INFO - 2015-12-30 20:50:01 --> Loader Class Initialized
INFO - 2015-12-30 20:50:01 --> Helper loaded: url_helper
INFO - 2015-12-30 20:50:01 --> Helper loaded: file_helper
INFO - 2015-12-30 20:50:01 --> Helper loaded: security_helper
INFO - 2015-12-30 20:50:01 --> Helper loaded: form_helper
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:50:01 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:50:01 --> Helper loaded: language_helper
INFO - 2015-12-30 20:50:01 --> Database Driver Class Initialized
INFO - 2015-12-30 20:50:01 --> Email Class Initialized
INFO - 2015-12-30 20:50:01 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:50:01 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:50:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:50:01 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Helper loaded: date_helper
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Controller Class Initialized
DEBUG - 2015-12-30 20:50:01 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 20:50:01 --> Model Class Initialized
INFO - 2015-12-30 20:50:01 --> Form Validation Class Initialized
INFO - 2015-12-30 20:50:01 --> Upload Class Initialized
DEBUG - 2015-12-30 20:50:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 20:50:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 20:50:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 20:50:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 20:50:01 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 20:50:01 --> Final output sent to browser
DEBUG - 2015-12-30 20:50:01 --> Total execution time: 0.0984
INFO - 2015-12-30 20:50:01 --> Config Class Initialized
INFO - 2015-12-30 20:50:01 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:01 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:01 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:01 --> URI Class Initialized
INFO - 2015-12-30 20:50:01 --> Router Class Initialized
INFO - 2015-12-30 20:50:01 --> Output Class Initialized
INFO - 2015-12-30 20:50:01 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:01 --> Input Class Initialized
INFO - 2015-12-30 20:50:01 --> Language Class Initialized
ERROR - 2015-12-30 20:50:01 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:02 --> Config Class Initialized
INFO - 2015-12-30 20:50:02 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:02 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:02 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:02 --> URI Class Initialized
INFO - 2015-12-30 20:50:02 --> Router Class Initialized
INFO - 2015-12-30 20:50:02 --> Output Class Initialized
INFO - 2015-12-30 20:50:02 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:02 --> Input Class Initialized
INFO - 2015-12-30 20:50:02 --> Language Class Initialized
ERROR - 2015-12-30 20:50:02 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:18 --> Config Class Initialized
INFO - 2015-12-30 20:50:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:18 --> URI Class Initialized
INFO - 2015-12-30 20:50:18 --> Router Class Initialized
INFO - 2015-12-30 20:50:18 --> Output Class Initialized
INFO - 2015-12-30 20:50:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:18 --> Input Class Initialized
INFO - 2015-12-30 20:50:18 --> Language Class Initialized
INFO - 2015-12-30 20:50:18 --> Language Class Initialized
INFO - 2015-12-30 20:50:18 --> Config Class Initialized
INFO - 2015-12-30 20:50:18 --> Loader Class Initialized
INFO - 2015-12-30 20:50:18 --> Helper loaded: url_helper
INFO - 2015-12-30 20:50:18 --> Helper loaded: file_helper
INFO - 2015-12-30 20:50:18 --> Helper loaded: security_helper
INFO - 2015-12-30 20:50:18 --> Helper loaded: form_helper
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:50:18 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:50:18 --> Helper loaded: language_helper
INFO - 2015-12-30 20:50:18 --> Database Driver Class Initialized
INFO - 2015-12-30 20:50:18 --> Email Class Initialized
INFO - 2015-12-30 20:50:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:50:18 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:50:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:50:18 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Helper loaded: date_helper
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Model Class Initialized
INFO - 2015-12-30 20:50:18 --> Controller Class Initialized
INFO - 2015-12-30 20:50:18 --> Form Validation Class Initialized
INFO - 2015-12-30 20:50:18 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-12-30 20:50:18 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/iconsloader.php
DEBUG - 2015-12-30 20:50:18 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/header.php
DEBUG - 2015-12-30 20:50:18 --> File loaded: /home/tritiyo/public_html/schools/application/views/auth/login.php
DEBUG - 2015-12-30 20:50:18 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/footer.php
INFO - 2015-12-30 20:50:18 --> Final output sent to browser
DEBUG - 2015-12-30 20:50:18 --> Total execution time: 0.0844
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:19 --> Output Class Initialized
INFO - 2015-12-30 20:50:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:19 --> Input Class Initialized
INFO - 2015-12-30 20:50:19 --> Language Class Initialized
ERROR - 2015-12-30 20:50:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:19 --> Config Class Initialized
INFO - 2015-12-30 20:50:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:19 --> URI Class Initialized
INFO - 2015-12-30 20:50:19 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:20 --> Config Class Initialized
INFO - 2015-12-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:20 --> URI Class Initialized
INFO - 2015-12-30 20:50:20 --> Router Class Initialized
INFO - 2015-12-30 20:50:20 --> Output Class Initialized
INFO - 2015-12-30 20:50:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:20 --> Input Class Initialized
INFO - 2015-12-30 20:50:20 --> Language Class Initialized
ERROR - 2015-12-30 20:50:20 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:21 --> Config Class Initialized
INFO - 2015-12-30 20:50:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:21 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:21 --> URI Class Initialized
INFO - 2015-12-30 20:50:21 --> Router Class Initialized
INFO - 2015-12-30 20:50:21 --> Output Class Initialized
INFO - 2015-12-30 20:50:21 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:21 --> Input Class Initialized
INFO - 2015-12-30 20:50:21 --> Language Class Initialized
ERROR - 2015-12-30 20:50:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:22 --> Config Class Initialized
INFO - 2015-12-30 20:50:22 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:22 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:22 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:22 --> URI Class Initialized
INFO - 2015-12-30 20:50:22 --> Router Class Initialized
INFO - 2015-12-30 20:50:22 --> Output Class Initialized
INFO - 2015-12-30 20:50:22 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:22 --> Input Class Initialized
INFO - 2015-12-30 20:50:22 --> Language Class Initialized
ERROR - 2015-12-30 20:50:22 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:50:22 --> Config Class Initialized
INFO - 2015-12-30 20:50:22 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:50:22 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:50:22 --> Utf8 Class Initialized
INFO - 2015-12-30 20:50:22 --> URI Class Initialized
INFO - 2015-12-30 20:50:22 --> Router Class Initialized
INFO - 2015-12-30 20:50:22 --> Output Class Initialized
INFO - 2015-12-30 20:50:22 --> Security Class Initialized
DEBUG - 2015-12-30 20:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:50:22 --> Input Class Initialized
INFO - 2015-12-30 20:50:22 --> Language Class Initialized
ERROR - 2015-12-30 20:50:22 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:15 --> Config Class Initialized
INFO - 2015-12-30 20:51:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:15 --> URI Class Initialized
INFO - 2015-12-30 20:51:15 --> Router Class Initialized
INFO - 2015-12-30 20:51:15 --> Output Class Initialized
INFO - 2015-12-30 20:51:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:15 --> Input Class Initialized
INFO - 2015-12-30 20:51:15 --> Language Class Initialized
INFO - 2015-12-30 20:51:15 --> Language Class Initialized
INFO - 2015-12-30 20:51:15 --> Config Class Initialized
INFO - 2015-12-30 20:51:15 --> Loader Class Initialized
INFO - 2015-12-30 20:51:15 --> Helper loaded: url_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: file_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: security_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: form_helper
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: language_helper
INFO - 2015-12-30 20:51:15 --> Database Driver Class Initialized
INFO - 2015-12-30 20:51:15 --> Email Class Initialized
INFO - 2015-12-30 20:51:15 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:51:15 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:51:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:51:15 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Helper loaded: date_helper
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Controller Class Initialized
INFO - 2015-12-30 20:51:15 --> Form Validation Class Initialized
INFO - 2015-12-30 20:51:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2015-12-30 20:51:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2015-12-30 20:51:15 --> Config Class Initialized
INFO - 2015-12-30 20:51:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:15 --> URI Class Initialized
INFO - 2015-12-30 20:51:15 --> Router Class Initialized
INFO - 2015-12-30 20:51:15 --> Output Class Initialized
INFO - 2015-12-30 20:51:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:15 --> Input Class Initialized
INFO - 2015-12-30 20:51:15 --> Language Class Initialized
INFO - 2015-12-30 20:51:15 --> Language Class Initialized
INFO - 2015-12-30 20:51:15 --> Config Class Initialized
INFO - 2015-12-30 20:51:15 --> Loader Class Initialized
INFO - 2015-12-30 20:51:15 --> Helper loaded: url_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: file_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: security_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: form_helper
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:51:15 --> Helper loaded: language_helper
INFO - 2015-12-30 20:51:15 --> Database Driver Class Initialized
INFO - 2015-12-30 20:51:15 --> Email Class Initialized
INFO - 2015-12-30 20:51:15 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:51:15 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:51:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:51:15 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Helper loaded: date_helper
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Model Class Initialized
INFO - 2015-12-30 20:51:15 --> Controller Class Initialized
DEBUG - 2015-12-30 20:51:15 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/iconsloader.php
DEBUG - 2015-12-30 20:51:15 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/sidebar.php
DEBUG - 2015-12-30 20:51:15 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/topnav.php
DEBUG - 2015-12-30 20:51:15 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/header.php
DEBUG - 2015-12-30 20:51:15 --> File loaded: /home/tritiyo/public_html/schools/application/views/profile/dashboard.php
DEBUG - 2015-12-30 20:51:15 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/footer.php
INFO - 2015-12-30 20:51:15 --> Final output sent to browser
DEBUG - 2015-12-30 20:51:15 --> Total execution time: 0.0828
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:16 --> Config Class Initialized
INFO - 2015-12-30 20:51:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:16 --> URI Class Initialized
INFO - 2015-12-30 20:51:16 --> Router Class Initialized
INFO - 2015-12-30 20:51:16 --> Output Class Initialized
INFO - 2015-12-30 20:51:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:16 --> Input Class Initialized
INFO - 2015-12-30 20:51:16 --> Language Class Initialized
ERROR - 2015-12-30 20:51:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:17 --> Config Class Initialized
INFO - 2015-12-30 20:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:17 --> URI Class Initialized
INFO - 2015-12-30 20:51:17 --> Router Class Initialized
INFO - 2015-12-30 20:51:17 --> Output Class Initialized
INFO - 2015-12-30 20:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:17 --> Input Class Initialized
INFO - 2015-12-30 20:51:17 --> Language Class Initialized
ERROR - 2015-12-30 20:51:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:18 --> Config Class Initialized
INFO - 2015-12-30 20:51:18 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:18 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:18 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:18 --> URI Class Initialized
INFO - 2015-12-30 20:51:18 --> Router Class Initialized
INFO - 2015-12-30 20:51:18 --> Output Class Initialized
INFO - 2015-12-30 20:51:18 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:18 --> Input Class Initialized
INFO - 2015-12-30 20:51:18 --> Language Class Initialized
ERROR - 2015-12-30 20:51:18 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:19 --> Config Class Initialized
INFO - 2015-12-30 20:51:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:19 --> URI Class Initialized
INFO - 2015-12-30 20:51:19 --> Router Class Initialized
INFO - 2015-12-30 20:51:19 --> Output Class Initialized
INFO - 2015-12-30 20:51:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:19 --> Input Class Initialized
INFO - 2015-12-30 20:51:19 --> Language Class Initialized
ERROR - 2015-12-30 20:51:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:51:19 --> Config Class Initialized
INFO - 2015-12-30 20:51:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:51:19 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:51:19 --> Utf8 Class Initialized
INFO - 2015-12-30 20:51:19 --> URI Class Initialized
INFO - 2015-12-30 20:51:19 --> Router Class Initialized
INFO - 2015-12-30 20:51:19 --> Output Class Initialized
INFO - 2015-12-30 20:51:19 --> Security Class Initialized
DEBUG - 2015-12-30 20:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:51:19 --> Input Class Initialized
INFO - 2015-12-30 20:51:19 --> Language Class Initialized
ERROR - 2015-12-30 20:51:19 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:14 --> Config Class Initialized
INFO - 2015-12-30 20:53:14 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:14 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:14 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:14 --> URI Class Initialized
INFO - 2015-12-30 20:53:14 --> Router Class Initialized
INFO - 2015-12-30 20:53:14 --> Output Class Initialized
INFO - 2015-12-30 20:53:14 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:14 --> Input Class Initialized
INFO - 2015-12-30 20:53:14 --> Language Class Initialized
INFO - 2015-12-30 20:53:14 --> Language Class Initialized
INFO - 2015-12-30 20:53:14 --> Config Class Initialized
INFO - 2015-12-30 20:53:14 --> Loader Class Initialized
INFO - 2015-12-30 20:53:14 --> Helper loaded: url_helper
INFO - 2015-12-30 20:53:14 --> Helper loaded: file_helper
INFO - 2015-12-30 20:53:14 --> Helper loaded: security_helper
INFO - 2015-12-30 20:53:14 --> Helper loaded: form_helper
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:53:14 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:53:14 --> Helper loaded: language_helper
INFO - 2015-12-30 20:53:14 --> Database Driver Class Initialized
INFO - 2015-12-30 20:53:14 --> Email Class Initialized
INFO - 2015-12-30 20:53:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:53:14 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:53:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:53:14 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Helper loaded: date_helper
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Model Class Initialized
INFO - 2015-12-30 20:53:14 --> Controller Class Initialized
DEBUG - 2015-12-30 20:53:14 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/iconsloader.php
DEBUG - 2015-12-30 20:53:14 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/sidebar.php
DEBUG - 2015-12-30 20:53:14 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/topnav.php
DEBUG - 2015-12-30 20:53:14 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/header.php
DEBUG - 2015-12-30 20:53:14 --> File loaded: /home/tritiyo/public_html/schools/application/views/profile/dashboard.php
DEBUG - 2015-12-30 20:53:14 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/footer.php
INFO - 2015-12-30 20:53:14 --> Final output sent to browser
DEBUG - 2015-12-30 20:53:14 --> Total execution time: 0.0853
INFO - 2015-12-30 20:53:14 --> Config Class Initialized
INFO - 2015-12-30 20:53:14 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:14 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:14 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:14 --> URI Class Initialized
INFO - 2015-12-30 20:53:14 --> Router Class Initialized
INFO - 2015-12-30 20:53:14 --> Output Class Initialized
INFO - 2015-12-30 20:53:14 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:14 --> Input Class Initialized
INFO - 2015-12-30 20:53:14 --> Language Class Initialized
ERROR - 2015-12-30 20:53:14 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:14 --> Config Class Initialized
INFO - 2015-12-30 20:53:14 --> Hooks Class Initialized
INFO - 2015-12-30 20:53:14 --> Config Class Initialized
INFO - 2015-12-30 20:53:14 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:14 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:14 --> Utf8 Class Initialized
DEBUG - 2015-12-30 20:53:14 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:14 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:14 --> URI Class Initialized
INFO - 2015-12-30 20:53:14 --> URI Class Initialized
INFO - 2015-12-30 20:53:14 --> Router Class Initialized
INFO - 2015-12-30 20:53:14 --> Router Class Initialized
INFO - 2015-12-30 20:53:14 --> Output Class Initialized
INFO - 2015-12-30 20:53:14 --> Output Class Initialized
INFO - 2015-12-30 20:53:14 --> Security Class Initialized
INFO - 2015-12-30 20:53:14 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:14 --> Input Class Initialized
DEBUG - 2015-12-30 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:14 --> Input Class Initialized
INFO - 2015-12-30 20:53:14 --> Language Class Initialized
INFO - 2015-12-30 20:53:14 --> Language Class Initialized
ERROR - 2015-12-30 20:53:14 --> 404 Page Not Found: /index
ERROR - 2015-12-30 20:53:14 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Config Class Initialized
INFO - 2015-12-30 20:53:15 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:15 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:15 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:15 --> URI Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
INFO - 2015-12-30 20:53:15 --> Router Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
INFO - 2015-12-30 20:53:15 --> Output Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:15 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:15 --> Input Class Initialized
INFO - 2015-12-30 20:53:15 --> Language Class Initialized
ERROR - 2015-12-30 20:53:15 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:16 --> Config Class Initialized
INFO - 2015-12-30 20:53:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:16 --> URI Class Initialized
INFO - 2015-12-30 20:53:16 --> Router Class Initialized
INFO - 2015-12-30 20:53:16 --> Output Class Initialized
INFO - 2015-12-30 20:53:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:16 --> Input Class Initialized
INFO - 2015-12-30 20:53:16 --> Language Class Initialized
ERROR - 2015-12-30 20:53:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:16 --> Config Class Initialized
INFO - 2015-12-30 20:53:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:16 --> URI Class Initialized
INFO - 2015-12-30 20:53:16 --> Router Class Initialized
INFO - 2015-12-30 20:53:16 --> Output Class Initialized
INFO - 2015-12-30 20:53:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:16 --> Input Class Initialized
INFO - 2015-12-30 20:53:16 --> Language Class Initialized
ERROR - 2015-12-30 20:53:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:16 --> Config Class Initialized
INFO - 2015-12-30 20:53:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:16 --> URI Class Initialized
INFO - 2015-12-30 20:53:16 --> Router Class Initialized
INFO - 2015-12-30 20:53:16 --> Output Class Initialized
INFO - 2015-12-30 20:53:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:16 --> Input Class Initialized
INFO - 2015-12-30 20:53:16 --> Language Class Initialized
ERROR - 2015-12-30 20:53:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:16 --> Config Class Initialized
INFO - 2015-12-30 20:53:16 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:16 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:16 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:16 --> URI Class Initialized
INFO - 2015-12-30 20:53:16 --> Router Class Initialized
INFO - 2015-12-30 20:53:16 --> Output Class Initialized
INFO - 2015-12-30 20:53:16 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:16 --> Input Class Initialized
INFO - 2015-12-30 20:53:16 --> Language Class Initialized
ERROR - 2015-12-30 20:53:16 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:17 --> Config Class Initialized
INFO - 2015-12-30 20:53:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:17 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:17 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:17 --> URI Class Initialized
INFO - 2015-12-30 20:53:17 --> Router Class Initialized
INFO - 2015-12-30 20:53:17 --> Output Class Initialized
INFO - 2015-12-30 20:53:17 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:17 --> Input Class Initialized
INFO - 2015-12-30 20:53:17 --> Language Class Initialized
ERROR - 2015-12-30 20:53:17 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:25 --> Config Class Initialized
INFO - 2015-12-30 20:53:25 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:25 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:25 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:25 --> URI Class Initialized
INFO - 2015-12-30 20:53:25 --> Router Class Initialized
INFO - 2015-12-30 20:53:25 --> Output Class Initialized
INFO - 2015-12-30 20:53:25 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:25 --> Input Class Initialized
INFO - 2015-12-30 20:53:25 --> Language Class Initialized
INFO - 2015-12-30 20:53:25 --> Language Class Initialized
INFO - 2015-12-30 20:53:25 --> Config Class Initialized
INFO - 2015-12-30 20:53:25 --> Loader Class Initialized
INFO - 2015-12-30 20:53:25 --> Helper loaded: url_helper
INFO - 2015-12-30 20:53:25 --> Helper loaded: file_helper
INFO - 2015-12-30 20:53:25 --> Helper loaded: security_helper
INFO - 2015-12-30 20:53:25 --> Helper loaded: form_helper
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:53:25 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:53:25 --> Helper loaded: language_helper
INFO - 2015-12-30 20:53:25 --> Database Driver Class Initialized
INFO - 2015-12-30 20:53:25 --> Email Class Initialized
INFO - 2015-12-30 20:53:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:53:25 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:53:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:53:25 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Helper loaded: date_helper
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Model Class Initialized
INFO - 2015-12-30 20:53:25 --> Controller Class Initialized
DEBUG - 2015-12-30 20:53:25 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/iconsloader.php
DEBUG - 2015-12-30 20:53:25 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/sidebar.php
DEBUG - 2015-12-30 20:53:25 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/topnav.php
DEBUG - 2015-12-30 20:53:25 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/header.php
DEBUG - 2015-12-30 20:53:25 --> File loaded: /home/tritiyo/public_html/schools/application/views/profile/dashboard.php
DEBUG - 2015-12-30 20:53:25 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/footer.php
INFO - 2015-12-30 20:53:25 --> Final output sent to browser
DEBUG - 2015-12-30 20:53:25 --> Total execution time: 0.0794
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:26 --> Router Class Initialized
INFO - 2015-12-30 20:53:26 --> Output Class Initialized
INFO - 2015-12-30 20:53:26 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:26 --> Input Class Initialized
INFO - 2015-12-30 20:53:26 --> Language Class Initialized
ERROR - 2015-12-30 20:53:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:26 --> Config Class Initialized
INFO - 2015-12-30 20:53:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:26 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:26 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:27 --> Config Class Initialized
INFO - 2015-12-30 20:53:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:27 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:27 --> URI Class Initialized
INFO - 2015-12-30 20:53:27 --> Router Class Initialized
INFO - 2015-12-30 20:53:27 --> Output Class Initialized
INFO - 2015-12-30 20:53:27 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:27 --> Input Class Initialized
INFO - 2015-12-30 20:53:27 --> Language Class Initialized
ERROR - 2015-12-30 20:53:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:28 --> Config Class Initialized
INFO - 2015-12-30 20:53:28 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:28 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:28 --> URI Class Initialized
INFO - 2015-12-30 20:53:28 --> Router Class Initialized
INFO - 2015-12-30 20:53:28 --> Output Class Initialized
INFO - 2015-12-30 20:53:28 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:28 --> Input Class Initialized
INFO - 2015-12-30 20:53:28 --> Language Class Initialized
ERROR - 2015-12-30 20:53:28 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:53:28 --> Config Class Initialized
INFO - 2015-12-30 20:53:28 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:53:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:53:28 --> Utf8 Class Initialized
INFO - 2015-12-30 20:53:28 --> URI Class Initialized
INFO - 2015-12-30 20:53:28 --> Router Class Initialized
INFO - 2015-12-30 20:53:28 --> Output Class Initialized
INFO - 2015-12-30 20:53:28 --> Security Class Initialized
DEBUG - 2015-12-30 20:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:53:28 --> Input Class Initialized
INFO - 2015-12-30 20:53:28 --> Language Class Initialized
INFO - 2015-12-30 20:53:28 --> Language Class Initialized
INFO - 2015-12-30 20:53:28 --> Config Class Initialized
INFO - 2015-12-30 20:53:28 --> Loader Class Initialized
INFO - 2015-12-30 20:53:28 --> Helper loaded: url_helper
INFO - 2015-12-30 20:53:28 --> Helper loaded: file_helper
INFO - 2015-12-30 20:53:28 --> Helper loaded: security_helper
INFO - 2015-12-30 20:53:28 --> Helper loaded: form_helper
INFO - 2015-12-30 20:53:28 --> Model Class Initialized
INFO - 2015-12-30 20:53:28 --> Model Class Initialized
INFO - 2015-12-30 20:53:28 --> Model Class Initialized
INFO - 2015-12-30 20:53:28 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:53:28 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:53:28 --> Helper loaded: language_helper
INFO - 2015-12-30 20:53:28 --> Database Driver Class Initialized
INFO - 2015-12-30 20:53:29 --> Email Class Initialized
INFO - 2015-12-30 20:53:29 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:53:29 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:53:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:53:29 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:53:29 --> Model Class Initialized
INFO - 2015-12-30 20:53:29 --> Helper loaded: date_helper
INFO - 2015-12-30 20:53:29 --> Model Class Initialized
INFO - 2015-12-30 20:53:29 --> Model Class Initialized
INFO - 2015-12-30 20:53:29 --> Model Class Initialized
INFO - 2015-12-30 20:53:29 --> Model Class Initialized
INFO - 2015-12-30 20:53:29 --> Controller Class Initialized
DEBUG - 2015-12-30 20:53:29 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/iconsloader.php
DEBUG - 2015-12-30 20:53:29 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/sidebar.php
DEBUG - 2015-12-30 20:53:29 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/topnav.php
DEBUG - 2015-12-30 20:53:29 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/header.php
DEBUG - 2015-12-30 20:53:29 --> File loaded: /home/tritiyo/public_html/schools/application/views/profile/dashboard.php
DEBUG - 2015-12-30 20:53:29 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/footer.php
INFO - 2015-12-30 20:53:29 --> Final output sent to browser
DEBUG - 2015-12-30 20:53:29 --> Total execution time: 0.0859
INFO - 2015-12-30 20:55:20 --> Config Class Initialized
INFO - 2015-12-30 20:55:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:55:20 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:55:20 --> Utf8 Class Initialized
INFO - 2015-12-30 20:55:20 --> URI Class Initialized
INFO - 2015-12-30 20:55:20 --> Router Class Initialized
INFO - 2015-12-30 20:55:20 --> Output Class Initialized
INFO - 2015-12-30 20:55:20 --> Security Class Initialized
DEBUG - 2015-12-30 20:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:55:20 --> Input Class Initialized
INFO - 2015-12-30 20:55:20 --> Language Class Initialized
INFO - 2015-12-30 20:55:20 --> Language Class Initialized
INFO - 2015-12-30 20:55:20 --> Config Class Initialized
INFO - 2015-12-30 20:55:20 --> Loader Class Initialized
INFO - 2015-12-30 20:55:20 --> Helper loaded: url_helper
INFO - 2015-12-30 20:55:20 --> Helper loaded: file_helper
INFO - 2015-12-30 20:55:20 --> Helper loaded: security_helper
INFO - 2015-12-30 20:55:20 --> Helper loaded: form_helper
INFO - 2015-12-30 20:55:20 --> Model Class Initialized
INFO - 2015-12-30 20:55:20 --> Model Class Initialized
INFO - 2015-12-30 20:55:20 --> Model Class Initialized
INFO - 2015-12-30 20:55:20 --> Helper loaded: scene_helper
INFO - 2015-12-30 20:55:20 --> Helper loaded: menu_helper
INFO - 2015-12-30 20:55:20 --> Helper loaded: language_helper
INFO - 2015-12-30 20:55:20 --> Database Driver Class Initialized
INFO - 2015-12-30 20:55:21 --> Email Class Initialized
INFO - 2015-12-30 20:55:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 20:55:21 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 20:55:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 20:55:21 --> Helper loaded: cookie_helper
INFO - 2015-12-30 20:55:21 --> Model Class Initialized
INFO - 2015-12-30 20:55:21 --> Helper loaded: date_helper
INFO - 2015-12-30 20:55:21 --> Model Class Initialized
INFO - 2015-12-30 20:55:21 --> Model Class Initialized
INFO - 2015-12-30 20:55:21 --> Model Class Initialized
INFO - 2015-12-30 20:55:21 --> Model Class Initialized
INFO - 2015-12-30 20:55:21 --> Controller Class Initialized
DEBUG - 2015-12-30 20:55:21 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/iconsloader.php
DEBUG - 2015-12-30 20:55:21 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/sidebar.php
DEBUG - 2015-12-30 20:55:21 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/topnav.php
DEBUG - 2015-12-30 20:55:21 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/header.php
DEBUG - 2015-12-30 20:55:21 --> File loaded: /home/tritiyo/public_html/schools/application/views/profile/dashboard.php
DEBUG - 2015-12-30 20:55:21 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/footer.php
INFO - 2015-12-30 20:55:21 --> Final output sent to browser
DEBUG - 2015-12-30 20:55:21 --> Total execution time: 0.6466
INFO - 2015-12-30 20:55:23 --> Config Class Initialized
INFO - 2015-12-30 20:55:23 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:55:23 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:55:23 --> Utf8 Class Initialized
INFO - 2015-12-30 20:55:23 --> URI Class Initialized
INFO - 2015-12-30 20:55:23 --> Router Class Initialized
INFO - 2015-12-30 20:55:23 --> Output Class Initialized
INFO - 2015-12-30 20:55:23 --> Security Class Initialized
DEBUG - 2015-12-30 20:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:55:23 --> Input Class Initialized
INFO - 2015-12-30 20:55:23 --> Language Class Initialized
ERROR - 2015-12-30 20:55:23 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:55:24 --> Config Class Initialized
INFO - 2015-12-30 20:55:24 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:55:24 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:55:24 --> Utf8 Class Initialized
INFO - 2015-12-30 20:55:24 --> URI Class Initialized
INFO - 2015-12-30 20:55:24 --> Router Class Initialized
INFO - 2015-12-30 20:55:24 --> Output Class Initialized
INFO - 2015-12-30 20:55:24 --> Security Class Initialized
DEBUG - 2015-12-30 20:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:55:24 --> Input Class Initialized
INFO - 2015-12-30 20:55:24 --> Language Class Initialized
ERROR - 2015-12-30 20:55:24 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:55:25 --> Config Class Initialized
INFO - 2015-12-30 20:55:25 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:55:25 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:55:25 --> Utf8 Class Initialized
INFO - 2015-12-30 20:55:25 --> URI Class Initialized
INFO - 2015-12-30 20:55:25 --> Router Class Initialized
INFO - 2015-12-30 20:55:25 --> Output Class Initialized
INFO - 2015-12-30 20:55:25 --> Security Class Initialized
DEBUG - 2015-12-30 20:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:55:25 --> Input Class Initialized
INFO - 2015-12-30 20:55:25 --> Language Class Initialized
ERROR - 2015-12-30 20:55:25 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:55:25 --> Config Class Initialized
INFO - 2015-12-30 20:55:25 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:55:25 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:55:25 --> Utf8 Class Initialized
INFO - 2015-12-30 20:55:25 --> URI Class Initialized
INFO - 2015-12-30 20:55:25 --> Router Class Initialized
INFO - 2015-12-30 20:55:25 --> Output Class Initialized
INFO - 2015-12-30 20:55:25 --> Security Class Initialized
DEBUG - 2015-12-30 20:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:55:25 --> Input Class Initialized
INFO - 2015-12-30 20:55:25 --> Language Class Initialized
ERROR - 2015-12-30 20:55:25 --> 404 Page Not Found: /index
INFO - 2015-12-30 20:55:25 --> Config Class Initialized
INFO - 2015-12-30 20:55:25 --> Hooks Class Initialized
DEBUG - 2015-12-30 20:55:25 --> UTF-8 Support Enabled
INFO - 2015-12-30 20:55:25 --> Utf8 Class Initialized
INFO - 2015-12-30 20:55:25 --> URI Class Initialized
INFO - 2015-12-30 20:55:25 --> Router Class Initialized
INFO - 2015-12-30 20:55:25 --> Output Class Initialized
INFO - 2015-12-30 20:55:25 --> Security Class Initialized
DEBUG - 2015-12-30 20:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 20:55:25 --> Input Class Initialized
INFO - 2015-12-30 20:55:25 --> Language Class Initialized
ERROR - 2015-12-30 20:55:25 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:08:26 --> Config Class Initialized
INFO - 2015-12-30 21:08:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:26 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:26 --> URI Class Initialized
INFO - 2015-12-30 21:08:26 --> Router Class Initialized
INFO - 2015-12-30 21:08:26 --> Output Class Initialized
INFO - 2015-12-30 21:08:26 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:26 --> Input Class Initialized
INFO - 2015-12-30 21:08:26 --> Language Class Initialized
INFO - 2015-12-30 21:08:26 --> Language Class Initialized
INFO - 2015-12-30 21:08:26 --> Config Class Initialized
INFO - 2015-12-30 21:08:26 --> Loader Class Initialized
INFO - 2015-12-30 21:08:26 --> Helper loaded: url_helper
INFO - 2015-12-30 21:08:26 --> Helper loaded: file_helper
INFO - 2015-12-30 21:08:26 --> Helper loaded: security_helper
INFO - 2015-12-30 21:08:26 --> Helper loaded: form_helper
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Helper loaded: scene_helper
INFO - 2015-12-30 21:08:26 --> Helper loaded: menu_helper
INFO - 2015-12-30 21:08:26 --> Helper loaded: language_helper
INFO - 2015-12-30 21:08:26 --> Database Driver Class Initialized
INFO - 2015-12-30 21:08:26 --> Email Class Initialized
INFO - 2015-12-30 21:08:26 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 21:08:26 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 21:08:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 21:08:26 --> Helper loaded: cookie_helper
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Helper loaded: date_helper
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Model Class Initialized
INFO - 2015-12-30 21:08:26 --> Controller Class Initialized
DEBUG - 2015-12-30 21:08:26 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/iconsloader.php
DEBUG - 2015-12-30 21:08:26 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/sidebar.php
DEBUG - 2015-12-30 21:08:26 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/topnav.php
DEBUG - 2015-12-30 21:08:26 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/header.php
DEBUG - 2015-12-30 21:08:26 --> File loaded: /home/tritiyo/public_html/schools/application/views/profile/dashboard.php
DEBUG - 2015-12-30 21:08:26 --> File loaded: /home/tritiyo/public_html/schools/application/views/layouts/footer.php
INFO - 2015-12-30 21:08:26 --> Final output sent to browser
DEBUG - 2015-12-30 21:08:26 --> Total execution time: 0.1137
INFO - 2015-12-30 21:08:26 --> Config Class Initialized
INFO - 2015-12-30 21:08:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:26 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:26 --> URI Class Initialized
INFO - 2015-12-30 21:08:26 --> Router Class Initialized
INFO - 2015-12-30 21:08:26 --> Output Class Initialized
INFO - 2015-12-30 21:08:26 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:26 --> Input Class Initialized
INFO - 2015-12-30 21:08:26 --> Language Class Initialized
ERROR - 2015-12-30 21:08:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:08:27 --> Config Class Initialized
INFO - 2015-12-30 21:08:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:27 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:27 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:27 --> URI Class Initialized
INFO - 2015-12-30 21:08:27 --> Router Class Initialized
INFO - 2015-12-30 21:08:27 --> Output Class Initialized
INFO - 2015-12-30 21:08:27 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:27 --> Input Class Initialized
INFO - 2015-12-30 21:08:27 --> Language Class Initialized
ERROR - 2015-12-30 21:08:27 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:08:28 --> Config Class Initialized
INFO - 2015-12-30 21:08:28 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:28 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:28 --> URI Class Initialized
INFO - 2015-12-30 21:08:28 --> Router Class Initialized
INFO - 2015-12-30 21:08:28 --> Output Class Initialized
INFO - 2015-12-30 21:08:28 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:28 --> Input Class Initialized
INFO - 2015-12-30 21:08:28 --> Language Class Initialized
ERROR - 2015-12-30 21:08:28 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:08:28 --> Config Class Initialized
INFO - 2015-12-30 21:08:28 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:28 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:28 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:28 --> URI Class Initialized
INFO - 2015-12-30 21:08:28 --> Router Class Initialized
INFO - 2015-12-30 21:08:28 --> Output Class Initialized
INFO - 2015-12-30 21:08:28 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:28 --> Input Class Initialized
INFO - 2015-12-30 21:08:28 --> Language Class Initialized
ERROR - 2015-12-30 21:08:28 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:08:34 --> Config Class Initialized
INFO - 2015-12-30 21:08:34 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:34 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:34 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:34 --> URI Class Initialized
DEBUG - 2015-12-30 21:08:34 --> No URI present. Default controller set.
INFO - 2015-12-30 21:08:34 --> Router Class Initialized
INFO - 2015-12-30 21:08:34 --> Output Class Initialized
INFO - 2015-12-30 21:08:34 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:34 --> Input Class Initialized
INFO - 2015-12-30 21:08:34 --> Language Class Initialized
INFO - 2015-12-30 21:08:34 --> Language Class Initialized
INFO - 2015-12-30 21:08:34 --> Config Class Initialized
INFO - 2015-12-30 21:08:34 --> Loader Class Initialized
INFO - 2015-12-30 21:08:34 --> Helper loaded: url_helper
INFO - 2015-12-30 21:08:34 --> Helper loaded: file_helper
INFO - 2015-12-30 21:08:34 --> Helper loaded: security_helper
INFO - 2015-12-30 21:08:34 --> Helper loaded: form_helper
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Helper loaded: scene_helper
INFO - 2015-12-30 21:08:34 --> Helper loaded: menu_helper
INFO - 2015-12-30 21:08:34 --> Helper loaded: language_helper
INFO - 2015-12-30 21:08:34 --> Database Driver Class Initialized
INFO - 2015-12-30 21:08:34 --> Email Class Initialized
INFO - 2015-12-30 21:08:34 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 21:08:34 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 21:08:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 21:08:34 --> Helper loaded: cookie_helper
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Helper loaded: date_helper
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Controller Class Initialized
DEBUG - 2015-12-30 21:08:34 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 21:08:34 --> Model Class Initialized
INFO - 2015-12-30 21:08:34 --> Form Validation Class Initialized
INFO - 2015-12-30 21:08:34 --> Upload Class Initialized
DEBUG - 2015-12-30 21:08:34 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 21:08:34 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 21:08:34 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/content.php
DEBUG - 2015-12-30 21:08:34 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 21:08:34 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/index.php
INFO - 2015-12-30 21:08:34 --> Final output sent to browser
DEBUG - 2015-12-30 21:08:34 --> Total execution time: 0.0989
INFO - 2015-12-30 21:08:35 --> Config Class Initialized
INFO - 2015-12-30 21:08:35 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:35 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:35 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:35 --> URI Class Initialized
INFO - 2015-12-30 21:08:35 --> Router Class Initialized
INFO - 2015-12-30 21:08:35 --> Output Class Initialized
INFO - 2015-12-30 21:08:35 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:35 --> Input Class Initialized
INFO - 2015-12-30 21:08:35 --> Language Class Initialized
ERROR - 2015-12-30 21:08:35 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:08:36 --> Config Class Initialized
INFO - 2015-12-30 21:08:36 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:08:36 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:08:36 --> Utf8 Class Initialized
INFO - 2015-12-30 21:08:36 --> URI Class Initialized
INFO - 2015-12-30 21:08:36 --> Router Class Initialized
INFO - 2015-12-30 21:08:36 --> Output Class Initialized
INFO - 2015-12-30 21:08:36 --> Security Class Initialized
DEBUG - 2015-12-30 21:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:08:36 --> Input Class Initialized
INFO - 2015-12-30 21:08:36 --> Language Class Initialized
ERROR - 2015-12-30 21:08:36 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:09:21 --> Config Class Initialized
INFO - 2015-12-30 21:09:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:09:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:09:21 --> Utf8 Class Initialized
INFO - 2015-12-30 21:09:21 --> URI Class Initialized
INFO - 2015-12-30 21:09:21 --> Router Class Initialized
INFO - 2015-12-30 21:09:21 --> Output Class Initialized
INFO - 2015-12-30 21:09:21 --> Security Class Initialized
DEBUG - 2015-12-30 21:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:09:21 --> Input Class Initialized
INFO - 2015-12-30 21:09:21 --> Language Class Initialized
INFO - 2015-12-30 21:09:21 --> Language Class Initialized
INFO - 2015-12-30 21:09:21 --> Config Class Initialized
INFO - 2015-12-30 21:09:21 --> Loader Class Initialized
INFO - 2015-12-30 21:09:21 --> Helper loaded: url_helper
INFO - 2015-12-30 21:09:21 --> Helper loaded: file_helper
INFO - 2015-12-30 21:09:21 --> Helper loaded: security_helper
INFO - 2015-12-30 21:09:21 --> Helper loaded: form_helper
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Helper loaded: scene_helper
INFO - 2015-12-30 21:09:21 --> Helper loaded: menu_helper
INFO - 2015-12-30 21:09:21 --> Helper loaded: language_helper
INFO - 2015-12-30 21:09:21 --> Database Driver Class Initialized
INFO - 2015-12-30 21:09:21 --> Email Class Initialized
INFO - 2015-12-30 21:09:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 21:09:21 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 21:09:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 21:09:21 --> Helper loaded: cookie_helper
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Helper loaded: date_helper
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Controller Class Initialized
DEBUG - 2015-12-30 21:09:21 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 21:09:21 --> Model Class Initialized
INFO - 2015-12-30 21:09:21 --> Form Validation Class Initialized
INFO - 2015-12-30 21:09:21 --> Upload Class Initialized
DEBUG - 2015-12-30 21:09:21 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 21:09:21 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 21:09:21 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/admission/agreed_part.php
DEBUG - 2015-12-30 21:09:21 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 21:09:21 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/admission/index.php
INFO - 2015-12-30 21:09:21 --> Final output sent to browser
DEBUG - 2015-12-30 21:09:21 --> Total execution time: 0.0990
INFO - 2015-12-30 21:09:21 --> Config Class Initialized
INFO - 2015-12-30 21:09:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:09:21 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:09:21 --> Utf8 Class Initialized
INFO - 2015-12-30 21:09:21 --> URI Class Initialized
INFO - 2015-12-30 21:09:21 --> Router Class Initialized
INFO - 2015-12-30 21:09:21 --> Output Class Initialized
INFO - 2015-12-30 21:09:21 --> Security Class Initialized
DEBUG - 2015-12-30 21:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:09:21 --> Input Class Initialized
INFO - 2015-12-30 21:09:21 --> Language Class Initialized
ERROR - 2015-12-30 21:09:21 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:09:25 --> Config Class Initialized
INFO - 2015-12-30 21:09:25 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:09:25 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:09:25 --> Utf8 Class Initialized
INFO - 2015-12-30 21:09:25 --> URI Class Initialized
INFO - 2015-12-30 21:09:25 --> Router Class Initialized
INFO - 2015-12-30 21:09:25 --> Output Class Initialized
INFO - 2015-12-30 21:09:25 --> Security Class Initialized
DEBUG - 2015-12-30 21:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:09:25 --> Input Class Initialized
INFO - 2015-12-30 21:09:25 --> Language Class Initialized
INFO - 2015-12-30 21:09:25 --> Language Class Initialized
INFO - 2015-12-30 21:09:25 --> Config Class Initialized
INFO - 2015-12-30 21:09:25 --> Loader Class Initialized
INFO - 2015-12-30 21:09:25 --> Helper loaded: url_helper
INFO - 2015-12-30 21:09:25 --> Helper loaded: file_helper
INFO - 2015-12-30 21:09:25 --> Helper loaded: security_helper
INFO - 2015-12-30 21:09:25 --> Helper loaded: form_helper
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Helper loaded: scene_helper
INFO - 2015-12-30 21:09:25 --> Helper loaded: menu_helper
INFO - 2015-12-30 21:09:25 --> Helper loaded: language_helper
INFO - 2015-12-30 21:09:25 --> Database Driver Class Initialized
INFO - 2015-12-30 21:09:25 --> Email Class Initialized
INFO - 2015-12-30 21:09:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 21:09:25 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 21:09:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 21:09:25 --> Helper loaded: cookie_helper
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Helper loaded: date_helper
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Controller Class Initialized
DEBUG - 2015-12-30 21:09:25 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 21:09:25 --> Model Class Initialized
INFO - 2015-12-30 21:09:25 --> Form Validation Class Initialized
INFO - 2015-12-30 21:09:25 --> Upload Class Initialized
INFO - 2015-12-30 21:09:25 --> Final output sent to browser
DEBUG - 2015-12-30 21:09:25 --> Total execution time: 0.0922
INFO - 2015-12-30 21:09:26 --> Config Class Initialized
INFO - 2015-12-30 21:09:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:09:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:09:26 --> Utf8 Class Initialized
INFO - 2015-12-30 21:09:26 --> URI Class Initialized
INFO - 2015-12-30 21:09:26 --> Router Class Initialized
INFO - 2015-12-30 21:09:26 --> Output Class Initialized
INFO - 2015-12-30 21:09:26 --> Security Class Initialized
DEBUG - 2015-12-30 21:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:09:26 --> Input Class Initialized
INFO - 2015-12-30 21:09:26 --> Language Class Initialized
INFO - 2015-12-30 21:09:26 --> Language Class Initialized
INFO - 2015-12-30 21:09:26 --> Config Class Initialized
INFO - 2015-12-30 21:09:26 --> Loader Class Initialized
INFO - 2015-12-30 21:09:26 --> Helper loaded: url_helper
INFO - 2015-12-30 21:09:26 --> Helper loaded: file_helper
INFO - 2015-12-30 21:09:26 --> Helper loaded: security_helper
INFO - 2015-12-30 21:09:26 --> Helper loaded: form_helper
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Helper loaded: scene_helper
INFO - 2015-12-30 21:09:26 --> Helper loaded: menu_helper
INFO - 2015-12-30 21:09:26 --> Helper loaded: language_helper
INFO - 2015-12-30 21:09:26 --> Database Driver Class Initialized
INFO - 2015-12-30 21:09:26 --> Email Class Initialized
INFO - 2015-12-30 21:09:26 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 21:09:26 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 21:09:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 21:09:26 --> Helper loaded: cookie_helper
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Helper loaded: date_helper
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Controller Class Initialized
DEBUG - 2015-12-30 21:09:26 --> Frontend MX_Controller Initialized
INFO - 2015-12-30 21:09:26 --> Model Class Initialized
INFO - 2015-12-30 21:09:26 --> Form Validation Class Initialized
INFO - 2015-12-30 21:09:26 --> Upload Class Initialized
DEBUG - 2015-12-30 21:09:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/scroller.php
DEBUG - 2015-12-30 21:09:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/header.php
DEBUG - 2015-12-30 21:09:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/admission/payment_part.php
DEBUG - 2015-12-30 21:09:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/layouts/bluetheme/footer.php
DEBUG - 2015-12-30 21:09:26 --> File loaded: /home/tritiyo/public_html/schools/application/modules/frontend/views/admission/index.php
INFO - 2015-12-30 21:09:26 --> Final output sent to browser
DEBUG - 2015-12-30 21:09:26 --> Total execution time: 0.1023
INFO - 2015-12-30 21:09:26 --> Config Class Initialized
INFO - 2015-12-30 21:09:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:09:26 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:09:26 --> Utf8 Class Initialized
INFO - 2015-12-30 21:09:26 --> URI Class Initialized
INFO - 2015-12-30 21:09:26 --> Router Class Initialized
INFO - 2015-12-30 21:09:26 --> Output Class Initialized
INFO - 2015-12-30 21:09:26 --> Security Class Initialized
DEBUG - 2015-12-30 21:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:09:26 --> Input Class Initialized
INFO - 2015-12-30 21:09:26 --> Language Class Initialized
ERROR - 2015-12-30 21:09:26 --> 404 Page Not Found: /index
INFO - 2015-12-30 21:09:40 --> Config Class Initialized
INFO - 2015-12-30 21:09:40 --> Hooks Class Initialized
DEBUG - 2015-12-30 21:09:40 --> UTF-8 Support Enabled
INFO - 2015-12-30 21:09:40 --> Utf8 Class Initialized
INFO - 2015-12-30 21:09:40 --> URI Class Initialized
INFO - 2015-12-30 21:09:40 --> Router Class Initialized
INFO - 2015-12-30 21:09:40 --> Output Class Initialized
INFO - 2015-12-30 21:09:40 --> Security Class Initialized
DEBUG - 2015-12-30 21:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-30 21:09:40 --> Input Class Initialized
INFO - 2015-12-30 21:09:40 --> Language Class Initialized
INFO - 2015-12-30 21:09:40 --> Language Class Initialized
INFO - 2015-12-30 21:09:40 --> Config Class Initialized
INFO - 2015-12-30 21:09:40 --> Loader Class Initialized
INFO - 2015-12-30 21:09:40 --> Helper loaded: url_helper
INFO - 2015-12-30 21:09:40 --> Helper loaded: file_helper
INFO - 2015-12-30 21:09:40 --> Helper loaded: security_helper
INFO - 2015-12-30 21:09:40 --> Helper loaded: form_helper
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Helper loaded: scene_helper
INFO - 2015-12-30 21:09:40 --> Helper loaded: menu_helper
INFO - 2015-12-30 21:09:40 --> Helper loaded: language_helper
INFO - 2015-12-30 21:09:40 --> Database Driver Class Initialized
INFO - 2015-12-30 21:09:40 --> Email Class Initialized
INFO - 2015-12-30 21:09:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2015-12-30 21:09:40 --> Config file loaded: /home/tritiyo/public_html/schools/application/config/ion_auth.php
INFO - 2015-12-30 21:09:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2015-12-30 21:09:40 --> Helper loaded: cookie_helper
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Helper loaded: date_helper
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Controller Class Initialized
INFO - 2015-12-30 21:09:40 --> Model Class Initialized
INFO - 2015-12-30 21:09:40 --> Form Validation Class Initialized
INFO - 2015-12-30 21:09:40 --> Upload Class Initialized
INFO - 2015-12-30 21:09:40 --> Final output sent to browser
DEBUG - 2015-12-30 21:09:40 --> Total execution time: 0.0874
