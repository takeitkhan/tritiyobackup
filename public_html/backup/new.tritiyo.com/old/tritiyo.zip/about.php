<?php include 'header.php'; ?>
    
	
        <section class="about-us erp_banner_area_two">
	        <ul class="list-unstyled cloud_animation">
	            <li><img src="img/erp-home/cloud_01.png" alt=""></li>
	            <li><img src="img/erp-home/cloud_02.png" alt=""></li>
	            <li><img src="img/erp-home/cloud_03.png" alt=""></li>
	            <li><img src="img/erp-home/cloud_04.png" alt=""></li>
	            <li><img src="img/erp-home/cloud_05.png" alt=""></li>
	            <li><img src="img/erp-home/cloud_06.png" alt=""></li>
	        </ul>
            <div class="erp_shap w-100"></div>
            <div class="erp_shap_two" style="background: url(img/erp-home/banner_shap.png) no-repeat scroll top left;"></div>
	        <div class="section_intro">
	            <div class="section_container">
	                <div class="intro">
	                    <div class=" intro_content">
	                        <h1>About Tritiyo Limited</h1>
	                        <h3>we fuel ideas that grow</h3>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <div class="animation_img wow fadeInUp" data-wow-delay="0.3s">
	            <div class="container">
	                    <p class="about-us-content-box">
	                        	Tritiyo Limited is a software and web application development company aimed at offering high-quality, moderately priced. We view ourselves as partners with our customers, our employees, our community and our environment. We aim to become a regionally recognized brand name, capitalizing on the sustained interest in Bangladesh. Our goal is moderate growth, annual profitability and maintaining our sense of humor. <br>

								We are a web application development, website development and designs company located in Dhaka, Bangladesh but we have developed projects for clients in the USA, Europe, Bangladesh, India, Italy, Latin America and more; we specialise in custom web programming, with main interest on complex websites but with all the skills and will to make websites of any size from basic personal and corporate to eCommerce websites. <br>

								If you are searching for an excellent web designer, an awesome programmer, and a dedicated project manager or virtual assistant, you have come to the right place; we grow everyday using project management, state-of-the-art web design software and common sense to produce standards-based and easy to use web sites. <br>

								We know that your budget may not be huge to design a website or that you don't want to risk too much of your money on that venture with your website specially when this economy downturn can lower your resources, that is why we charge affordable prices on our projects, and since we are located in Dhaka, Bangladesh where the exchange rates benefits you, you can be sure that you are going to pay hundreds or thousands of dollars less than you should pay in the USA or Europe. <br>
	                    </p>
	            </div>
	        </div>
        </section>

        <section class="erp_features_area_two sec_pad">
            <div class="container">
                <div class="row erp_item_features align-items-center flex-row-reverse">
                    <div class="col-lg-6">
                        <div class="erp_features_img_two">
                            <div class="img_icon"><span class="pluse_1"></span><span class="pluse_2"></span><i class="icon_lightbulb_alt"></i></div>
                            <img src="img/seo/features_img.png" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="erp_content_two pr-2">
                            <div class="hosting_title erp_title">
                                <h2>Story of Tritiyo Limited</h2>
                                <p>
                                	Founded in 2009, Tritiyo Limited started as oDesk Agency, A professional web design and web application development company. Our passion and expertise inspired us to take web application development as a profession. <br>

									We are constantly improving our knowledge and expanding our services to provide our customers with the highest level of professional help for their projects. <br>

									Our passion is to develop ease to use, attractive, modifiable, search engine friendly websites and web applications for you. In addition to this, we know how to promote you and we offer all of this with affordable price. <br>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    


<?php include 'footer.php'; ?>