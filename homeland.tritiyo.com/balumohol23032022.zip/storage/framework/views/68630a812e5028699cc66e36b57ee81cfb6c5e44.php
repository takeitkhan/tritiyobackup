<?php $__env->startSection('title'); ?>
    Create Ledger
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Ledger',
            'spSubTitle' => 'Enter a ledger information',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('ledgers.create'),
            'spAllData' => route('ledgers.index'),
            'spSearchData' => route('ledgers.search'),
            'spTitle' => 'All Ledger',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search ledgers...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>
<?php $__env->startSection('column_left'); ?>
    <article class="panel is-primary">
            <?php
                if (!empty($ledger) && $ledger->id) {
                    $routeUrl = route('ledgers.update', $ledger->id);
                    $method = 'PUT';
                } else {
                    $routeUrl = route('ledgers.store');
                    $method = 'post';
                }
            ?>

        <div class="customContainer">
            <?php echo e(Form::open(array('url' => $routeUrl, 'method' => $method, 'value' => 'PATCH', 'id' => 'add_route', 'files' => true, 'autocomplete' => 'off'))); ?>

            <div class="columns">
                <div class="column is-3">
                    <div class="field">
                        <?php echo e(Form::label('name', 'Name', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::text('name', $ledger->name ?? NULL, ['class' => 'input is-small', 'placeholder' => 'Enter name...'])); ?>

                        </div>
                    </div>
                </div>
                <div class="column is-3">
                    <div class="field">
                        <?php echo e(Form::label('type', 'Type', array('class' => 'label'))); ?>

                        <div class="control">
                            <select class="input is-small" name="type">
                                <option value="" selected disabled>Select Type</option>
                                <option value="receive" <?php echo e(!empty($ledger) && $ledger->type == 'receive' ? 'selected' : ''); ?>>receive</option>
                                <option value="pay" <?php echo e(!empty($ledger) && $ledger->type == 'pay' ? 'selected' : ''); ?>>Pay</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <div class="columns">
                 <div class="column is-12">
                    <div class="field">
                        <?php echo e(Form::label('description', 'Description', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::textarea('description', $ledger->description ?? NULL, ['class' => 'textarea is-small', 'placeholder' => 'Enter description...'])); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="columns">

            </div>

            <div class="columns">
                <div class="column">
                    <div class="field is-grouped">
                        <div class="control">
                            <button class="button is-success is-small">Save Changes</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('column_right'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/skeleton/tritiyo/homeland/src/views/ledger/create.blade.php ENDPATH**/ ?>