<nav class="navbar o_main_navbar is-navbar-bg is-link is-fixed-top" role="navigation" aria-label="dropdown navigation">
    <div class="navbar-brand">
        <a href="<?php echo e(url('dashboard')); ?>" class="navbar-item">
            <span class="navbar-item" class="o_menu_brand" href="javascript:void(0)">
                <img src="<?php echo e(asset('public/images/bizboss.png')); ?>"/>
            </span>
            
        </a>


        <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false"
           data-target="navbarExampleTransparentExample">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
        </a>
    </div>
    <div id="navbarExampleTransparentExample" class="navbar-menu">

        <div class="navbar-start">
            <?php echo $__env->yieldContent('header_title_set'); ?>
            <?php $routelist = \App\Models\Routelist::where('show_menu', '=', 1)->where('is_active', '=', 1)->get(); ?>
            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link" href="javascript:void(0)">
                    <i class="fas fa-bars"></i>&nbsp; Quick links
                </a>

                <div class="navbar-dropdown">
                    <?php $__currentLoopData = $routelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $selected = explode(",", $menu->to_role);
                        ?>
                        <?php if(!empty(Auth::user()->role)): ?>
                            <?php if(in_array(Auth::user()->role, $selected)): ?>
                                <?php if($menu->route_url == '#' || $menu->route_url == NULL): ?>
                                    <?php $link = '#'; ?>
                                <?php else: ?>
                                    <?php $link = route($menu->route_url) . '?route_id=' . $menu->id; ?>
                                <?php endif; ?>
                                <a href="<?php echo e($link ?? NULL); ?>"
                                   class="navbar-item">
                                    <i class="<?php echo e($menu->font_awesome ?? NULL); ?>"></i>&nbsp; <?php echo e($menu->route_name); ?>

                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    

                    
                </div>
            </div>
        </div>


        <?php echo $__env->yieldContent('header_button_set'); ?>


        <div class="navbar-end">
          
            <div class="navbar-item has-dropdown is-hoverable">
                <?php $current_user = auth()->user(); //dump($current_user)?>
                <a class="navbar-link">
                    <figure class="image is-16x16" style="margin-right: 5px;">
                        <img class="is-rounded" src="<?php echo e(asset('/resources/views/image/avatar.jpg')); ?>">
                    </figure>
                    Welcome, <strong style="color: yellow"> &nbsp;<?php echo e(@$current_user->name); ?> &nbsp;</strong>
                    as <?php echo e(\App\Models\Role::where('id', $current_user->role)->first()->name); ?>

                </a>
                <div class="navbar-dropdown is-right">
                    <?php if(auth()->user()->isAdmin(auth()->user()->id) || auth()->user()->isHR(auth()->user()->id)): ?>
                        <a class="navbar-item" href="<?php echo e(route('settings.global', 1)); ?>">
                            <i class="fas fa-wrench"></i>&nbsp;Global Settings
                        </a>
                        <a class="navbar-item" href="<?php echo e(route('settings.payment', 2)); ?>">
                            <i class="fas fa-dollar-sign"></i>&nbsp;Payment Settings
                        </a>
                        <a class="navbar-item" href="<?php echo e(route('settings.time', 3)); ?>">
                            <i class="fas fa-clock"></i>&nbsp;Time Settings
                        </a>
                        <a href="<?php echo e(url('routelists')); ?>" class="navbar-item">
                            <i class="fas fa-link"></i>&nbsp;Route Lists
                        </a>
                        <hr class="navbar-divider">
                    <?php endif; ?>
                    <div class="navbar-item">
                        <i class="fas fa-key"></i>&nbsp;
                        <a href="<?php echo e(route('users.change_password', auth()->user()->id)); ?>">
                            Change Password
                        </a>
                    </div>
                    <div class="navbar-item">
                        <i class="fas fa-sign-out-alt"></i>&nbsp;<a href="<?php echo e(url('logout')); ?>">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>

<?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style type="text/css">
    .transaction_summary {
        padding: 0 10px;
    }
</style>



<?php /**PATH /home/khabar/public_html/resources/views/layouts/header.blade.php ENDPATH**/ ?>