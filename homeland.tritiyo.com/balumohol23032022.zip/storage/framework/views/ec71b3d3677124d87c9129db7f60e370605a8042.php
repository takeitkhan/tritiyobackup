<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <p><?php echo $messages ?></p>
  </body>
</html>
<?php /**PATH /var/www/html/skeleton/resources/views/email.blade.php ENDPATH**/ ?>