<?php $__env->startSection('title'); ?>
    Create income
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Add Income',
            'spSubTitle' => 'Enter an income information',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('incomes.create'),
            'spAllData' => route('incomes.index'),
            'spSearchData' => route('incomes.search'),
            'spTitle' => 'All Income',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search incomes...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>
<?php $__env->startSection('column_left'); ?>
    <div class="columns">
        <div class="column is-8">
            <article class="panel is-primary">
                <?php
                if (!empty($income) && $income->id) {
                    $routeUrl = route('incomes.update', $income->id);
                    $method = 'PUT';
                } else {
                    $routeUrl = route('incomes.store');
                    $method = 'post';
                }
                ?>

                <div class="p-5">
                    <?php echo e(Form::open(array('url' => $routeUrl, 'method' => $method, 'value' => 'PATCH', 'id' => 'add_route', 'files' => true, 'autocomplete' => 'off'))); ?>

                    <div class="columns">
                        <div class="column is-4">
                            <div class="field width100">
                                <?php echo e(Form::label('date', 'Date', array('class' => 'label'))); ?>

                                <div class="control">
                                    <input style="background: #ddd" type="text" class="input is-small" name="date"
                                           value="<?php echo e(!empty($income) ? $income->date : date('Y-m-d')); ?>" readonly/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="columns">
                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('Ledger_id', 'Ledger Name', array('class' => 'label'))); ?>

                                <div class="select is-small is-fullwidth">

                                    <select name="ledger_id" class="">
                                        <option value="" disabled selected>Select a ledger</option>
                                        <?php
                                            $ledger = \Tritiyo\Homeland\Models\Ledger::orderBy('id', 'DESC')
                                                        ->where('type', 'receive')->get();
                                        ?>

                                        <?php $__currentLoopData = $ledger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($data->id); ?>" <?php echo e(!empty($income) && $income->ledger_id == $data->id ? 'selected' : ''); ?> >
                                                <?php echo e($data->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="columns">
                        <div class="column is-3">
                            <div class="field width100">
                                <?php echo e(Form::label('customer', 'Customer', array('class' => 'label'))); ?>

                                <div class="select is-small is-fullwidth">
                                    <?php if(!empty($income)): ?>
                                        <select class="" name="transaction_with" readonly>
                                            <?php $customer = \Tritiyo\Homeland\Models\Customer::where('id', $income->transaction_with)->first(); ?>
                                            <option value="<?php echo e($customer->id); ?>" selected><?php echo e($customer->name); ?></option>
                                        </select>
                                    <?php else: ?>
                                        <select class="" name="customer_type" id="customer_type">
                                            <option value="" selected disabled>Select Type</option>
                                            <option value="new">New</option>
                                            <option value="existing">Existing</option>
                                        </select>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>

                        <!--- Bolgate -->

                        <div class="column is-9" style="margin-top: 7px;">
                            <div class="columns" id="customer_field">

                            </div>
                        </div>


                    </div>

                    <div class="columns">
                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('payment_type', 'Payment Type', array('class' => 'label'))); ?>

                                <div class="select is-small is-fullwidth">
                                    <select class="" name="payment_type">
                                        <option value="" selected disabled>Select Type</option>
                                        <option
                                            value="bkash" <?php echo e(!empty($income) && $income->payment_type == 'bkash' ? 'selected' : ''); ?>>
                                            Bkash
                                        </option>
                                        <option
                                            value="bank" <?php echo e(!empty($income) && $income->payment_type == 'bank' ? 'selected' : ''); ?>>
                                            Bank
                                        </option>
                                        <option
                                            value="cash" <?php echo e(!empty($income) && $income->payment_type == 'cash' ? 'selected' : ''); ?>>
                                            Cash
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="columns">
                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('truck_number', 'Truck Number', array('class' => 'label'))); ?>

                                <div class="control">
                                    <input type="text" class="input is-small" name="truck_number"
                                           value="<?php echo e(!empty($income) ? $income->truck_number : ''); ?>"/>
                                </div>
                            </div>
                        </div>

                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('token_number', 'Token Number', array('class' => 'label'))); ?>

                                <div class="control">
                                    <input type="text" class="input is-small" name="token_number"
                                           value="<?php echo e(!empty($income) ? $income->token_number : ''); ?>"/>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="columns">
                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('per_unit_amount', 'Per Unit Amount', array('class' => 'label'))); ?>

                                <div class="control">
                                    <?php echo e(Form::text('per_unit_amount', $income->per_unit_amount ?? 0, ['class' => 'input is-small', 'placeholder' => 'Enter per unit amount...'])); ?>

                                </div>
                            </div>
                        </div>

                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('qty', 'Quantity/ Feet', array('class' => 'label'))); ?>

                                <div class="control">
                                    <?php echo e(Form::number('qty', $income->qty ?? 1, ['class' => 'input is-small', 'placeholder' => 'Enter quantity or feet...'])); ?>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="columns">
                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('actual_amount', 'Actual Amount', array('class' => 'label'))); ?>

                                <div class="control">
                                    <?php echo e(Form::text('actual_amount', $income->actual_amount ?? NULL, ['class' => 'input is-small', 'readonly' => true, 'placeholder' => 'Enter actual amount...'])); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="columns">
                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('discount', 'Discount', array('class' => 'label'))); ?>

                                <div class="control">
                                    <?php echo e(Form::text('discount', $income->discount ?? 0, ['class' => 'input is-small', 'placeholder' => 'Enter discount...'])); ?>

                                    <strong>[Discount in amount]</strong>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="columns">
                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('amount', 'Amount', array('class' => 'label'))); ?>

                                <div class="control">
                                    <?php echo e(Form::text('amount', $income->amount ?? NULL, ['class' => 'input is-small', 'readonly' => true, 'placeholder' => 'Enter Amount...'])); ?>

                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="columns">
                        <div class="column">
                            <div class="field is-grouped">
                                <div class="control">
                                    <button class="button is-success is-small">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </article>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('column_right'); ?>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('cusjs'); ?>

    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


    <script id="existing_customer" type="text/template">
        <div class="column is-4">
            <div class="field width100">
                <?php echo e(Form::label('', 'Select Customer', array('class' => 'label'))); ?>

                <div class="select is-small is-fullwidth">
                    <select class="" name="transaction_with">
                        <?php $customer = \Tritiyo\Homeland\Models\Customer::orderBy('id', 'DESC')->get(); ?>
                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </script>



    <script id="new_customer" type="text/template">
        <div class="column is-4">
            <div class="field width100">
                <?php echo e(Form::label('customer_name', 'Customer Name', array('class' => 'label'))); ?>

                <div class="control">
                    <input type="text" class="input is-small" name="customer_name" placeholder="Enter Customer name"/>
                </div>
            </div>
        </div>
        <div class="column is-4">
            <div class="field width100">
                <?php echo e(Form::label('customer_phone', 'Customer Phone', array('class' => 'label'))); ?>

                <div class="control">
                    <input type="text" class="input is-small" name="customer_phone" placeholder="Enter Customer Phone"/>
                </div>
            </div>
        </div>

        <div class="column is-4">
            <div class="field width100">
                <?php echo e(Form::label('customer_company', 'Customer Company', array('class' => 'label'))); ?>

                <div class="control">
                    <input type="text" class="input is-small" name="customer_company"
                           placeholder="Enter Customer Company"/>
                </div>
            </div>
        </div>

    </script>



    <script>
        $.noConflict();
        jQuery(document).ready(function ($) {
            $.noConflict();

            //$('#income_wrap').html($('#income_breakdown').html());
            function tr() {
                $('select#customer_type').change(function (e) {
                    // alert();
                    let getVal = $(this).find(':selected').val();
                    if (getVal == 'new') {
                        $('#customer_field').empty().append($('#new_customer').html())
                    }

                    if (getVal == 'existing') {
                        $('#customer_field').empty().append($('#existing_customer').html())
                    }


                });
            }

            tr();

            $('#other select').change(function (e) {
                //let selectedval = $(this).find(':selected').val();
                alert('ok');
                //$('input.referenceinput').attr('placeholder', 'Enter'+selectedval+'no');

            });
        });


        // Amount Disocunt Calculation
        let perUnitAmount = 0;
        $('input#per_unit_amount').keyup(function () {
            perUnitAmount = $(this).val();
            $('input#actual_amount').val(perUnitAmount * qty);
            $('input#amount').val((perUnitAmount * qty) - discount);


        })

        let qty = $('input#qty').val();
        $('input#qty').keyup(function () {
            qty = $(this).val();
            $('input#actual_amount').val(perUnitAmount * qty);
            $('input#amount').val((perUnitAmount * qty) - discount);
        })


        let discount = $('input#discount').val();
        $('input#discount').keyup(function () {
            discount = $('input#discount').val();
            //console.log(actualAmount)
            $('input#amount').val((perUnitAmount * qty) - discount);
        })


        /*
        let actualAmount = 0;
        $('input#actual_amount').keyup(function(){
            actualAmount = $(this).val();
            //let discount = $('input#discount').val();
            $('input#amount').val(actualAmount - discount);
        })
        */


        //$('input#amount').val()

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/khabar/public_html/tritiyo/homeland/src/views/income/create.blade.php ENDPATH**/ ?>