<?php $__env->startSection('title'); ?>
    Expenses
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Purchases',
            'spSubTitle' => 'all purchases here',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('purchases.create'),
            'spAllData' => route('purchases.index'),
            'spSearchData' => route('purchases.search'),
            'spTitle' => 'All purchases',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search purchases...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>

<?php $__env->startSection('column_left'); ?>
    <div class="columns is-multiline">
        <?php if(!empty($purchases)): ?>
            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column is-2">
                    <div class="borderedCol">
                        <article class="media">
                            <div class="media-content">
                                <div class="content">
                                    <p>
                                        Sand Type:
                                        <strong>
                                            <a href="<?php echo e(route('purchases.show', $purchase->id)); ?>"
                                               title="View route">
                                              
                                                <strong>
                                                    <?php echo e(ucfirst($purchase->sand_type)); ?>

                                               </strong>
                                            </a>
                                        </strong>
                                        <br/>
                                        <small>
                                           Date:  <strong><?php echo e($purchase->date); ?></strong>
                                        </small>
                                        <br/>
                                        <small>
                                          Bolgate :  <strong>

                                            <?php echo \Tritiyo\Homeland\Models\Bolgate::where('id', $purchase->bolgate_id)->first()->name;?>
                                            </strong>
                                        </small>
                                        <br/>
                                        <small>
                                           Feet:  <strong><?php echo e($purchase->qty); ?></strong>
                                        </small>
                                        <br>
                                        <small>
                                           Purchase Rate :  <strong><?php echo e($purchase->actual_amount); ?></strong>
                                        </small>
                                        <br>
                                        <small>
                                           Target Sale Rate :  <strong><?php echo e($purchase->target_sale_amount); ?></strong>
                                        </small>

                                    </p>
                                </div>
                                <nav class="level is-mobile">
                                    <div class="level-left">
                                        <a href="<?php echo e(route('purchases.show', $purchase->id)); ?>"
                                           class="level-item"
                                           title="View user data">
                                            <span class="icon is-small"><i class="fas fa-eye"></i></span>
                                        </a>
                                        <a href="<?php echo e(route('purchases.edit', $purchase->id)); ?>"
                                           class="level-item"
                                           title="View all transaction">
                                            <span class="icon is-info is-small"><i class="fas fa-edit"></i></span>
                                        </a>

                                        <!-- <?php echo delete_data('purchases.destroy',  $purchase->id); ?> -->
                                    </div>
                                </nav>
                            </div>
                        </article>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="pagination_wrap pagination">
                <?php echo e($purchases->links('pagination::bootstrap-4')); ?>    
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/khabar/public_html/tritiyo/homeland/src/views/purchase/index.blade.php ENDPATH**/ ?>