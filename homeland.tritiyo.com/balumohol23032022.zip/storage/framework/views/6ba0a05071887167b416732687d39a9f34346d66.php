<?php echo $__env->make('component.title_set', [
    'spTitle' => 'Settings',
    'spSubTitle' => 'settings data',
    'spAddUrl' => route('settings.create'),
    'spAllData' => route('settings.index'),
    'spSearchData' => '#',
    'spExportCSV' => null,
    'spPlaceholder' => 'Search user...',
    'spMessage' => $message = $message ?? NULl,
    'spStatus' => $status = $status ?? NULL
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('column_left'); ?>
    <div class="columns is-multiline">
        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column is-one-quarter">
                <div class="borderedCol">
                    <article class="media">
                        <div class="media-content">
                            <div class="content">
                                <p>
                                    <strong>
                                        <a href="<?php echo e(route('settings.show', $setting->id)); ?>"
                                           title="View setting">
                                            <?php echo e($setting); ?>

                                        </a>
                                    </strong>
                                </p>
                            </div>
                            <nav class="level is-mobile">
                                <div class="level-left">
                                    <a href="<?php echo e(route('users.show', $setting->id)); ?>"
                                       class="level-item"
                                       title="View user data">
                                        <span class="icon is-small"><i class="fas fa-eye"></i></span>
                                    </a>
                                    <a href="<?php echo e(route('settings', $setting->id)); ?>"
                                       class="level-item"
                                       title="View all transaction">
                                        <span class="icon is-info is-small"><i class="fas fa-edit"></i></span>
                                    </a>
                                    <a class="level-item" title="Delete user" href="javascript:void(0)"
                                       onclick="confirm('Are you sure?')">
                                        <span class="icon is-small is-red"><i class="fas fa-times"></i></span>
                                    </a>
                                </div>
                            </nav>
                        </div>
                    </article>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/skeleton/resources/views/settings/index.blade.php ENDPATH**/ ?>