<div class="column is-1">
        <div class="level-item is-4">
        <?php if(!empty($spAllData)): ?>
            <a href="<?php echo e($spAllData  ?? NULL); ?>"
            class="button is-small <?php echo e($spCss  ?? 'is-info-light'); ?> is-rounded"
            aria-haspopup="true"
            aria-controls="dropdown-menu3">
                <span><i class="fas fa-database"></i> <?php echo e($spTitle ?? 'All Datas'); ?></span>
            </a>
            <?php endif; ?>
            <?php if($spAddUrl != '#'): ?>
            <a href="<?php echo e($spAddUrl ?? NULL); ?>" class="button is-small is-info-light is-rounded" aria-haspopup="true"
            aria-controls="dropdown-menu">
                <span><i class="fas fa-plus"></i> Add</span>
            </a>
        <?php endif; ?>    
    </div>
</div><?php /**PATH /var/www/html/skeleton/resources/views/component/any_link.blade.php ENDPATH**/ ?>