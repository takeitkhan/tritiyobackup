<?php $__env->startSection('title'); ?>
    income
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Income',
            'spSubTitle' => 'all income here',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('incomes.create'),
            'spAllData' => route('incomes.index'),
            'spSearchData' => route('incomes.search'),
            'spTitle' => 'All incomes',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search incomes...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>

<?php $__env->startSection('column_left'); ?>
    <div class="columns is-multiline">
        <?php if(!empty($incomes)): ?>
            <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column is-2">
                    <div class="borderedCol">
                        <article class="media">
                            <div class="media-content">
                                <div class="content">
                                    <p>
                                        Ledger Name:
                                        <strong>
                                            <a href="<?php echo e(route('incomes.show', $income->id)); ?>"
                                               title="View route">
                                                <strong>
                                                    <?php echo \Tritiyo\Homeland\Models\Ledger::where('id', $income->ledger_id)->first()->name;?>
                                                </strong>
                                            </a>
                                        </strong>
                                        <br/>
                                        <small>
                                            Date: <strong><?php echo e($income->date); ?></strong>
                                        </small>
                                        <br/>
                                        <small>
                                            Transaction With Type: <strong><?php echo e($income->transaction_with_type); ?></strong>
                                        </small>
                                        <br/>
                                        <small>
                                            Transaction With :
                                            <strong>
                                                <?php
                                                    $customer = \Tritiyo\Homeland\Models\Customer::where('id', $income->transaction_with)->first();
                                                ?>
                                                <?php echo e($customer->name); ?>

                                            </strong>
                                        </small>
                                        <br/>
                                        <small>
                                            Phone : <strong><?php echo e($customer->phone); ?></strong>
                                        
                                        </small>
                                        <br/>
                                        <small>
                                            Payment Type: <strong><?php echo e($income->payment_type); ?></strong>
                                        </small>

                                    </p>
                                </div>
                                <nav class="level is-mobile">
                                    <div class="level-left">
                                        <a href="<?php echo e(route('incomes.show', $income->id)); ?>"
                                           class="level-item"
                                           title="View user data">
                                            <span class="icon is-small"><i class="fas fa-eye"></i></span>
                                        </a>
                                        <a href="<?php echo e(route('incomes.edit', $income->id)); ?>"
                                           class="level-item"
                                           title="View all transaction">
                                            <span class="icon is-info is-small"><i class="fas fa-edit"></i></span>
                                        </a>

                                        <!-- <?php echo delete_data('incomes.destroy',  $income->id); ?> -->
                                    </div>
                                </nav>
                            </div>
                        </article>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="pagination_wrap pagination">
                <?php echo e($incomes->links('pagination::bootstrap-4')); ?>    
            </div>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/khabar/public_html/tritiyo/homeland/src/views/income/index.blade.php ENDPATH**/ ?>