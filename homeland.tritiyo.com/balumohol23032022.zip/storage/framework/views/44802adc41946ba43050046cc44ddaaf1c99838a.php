<?php $__env->startSection('title'); ?>
    Expenses
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Expenses',
            'spSubTitle' => 'all expenses here',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('expenses.create'),
            'spAllData' => route('expenses.index'),
            'spSearchData' => route('expenses.search'),
            'spTitle' => 'All Expenses',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search expenses...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>

<?php $__env->startSection('column_left'); ?>
    <div class="columns is-multiline">
        <?php if(!empty($expenses)): ?>
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column is-2">
                    <div class="borderedCol">
                        <article class="media">
                            <div class="media-content">
                                <div class="content">
                                    <p>
                                        <strong>
                                            <a href="<?php echo e(route('expenses.show', $expense->id)); ?>"
                                               title="View route">
                                               Ledger Name:<strong>
                                                    <?php echo \Tritiyo\Homeland\Models\Ledger::where('id', $expense->ledger_id)->first()->name ;?>
                                               </strong>
                                            </a>
                                        </strong>
                                        <br/>
                                        <small>
                                           Transaction With Type:  <strong><?php echo e($expense->transaction_with_type); ?></strong>
                                        </small>
                                        <br/>
                                        <small>
                                           Transaction With :  <strong>

                                                <?php if($expense->transaction_with_type == 'bolgate'): ?>

                                                    <?php echo e(\Tritiyo\Homeland\Models\Bolgate::where('id', $expense->transaction_with)->first()->name); ?>- <?php echo e($expense->reference); ?>


                                                <?php elseif($expense->transaction_with_type == 'staff'): ?>

                                                    <?php echo e(\App\Models\User::where('id', $expense->transaction_with)->first()->name); ?>- <?php echo e($expense->reference); ?>


                                                <?php elseif($expense->transaction_with_type == 'other'): ?>
                                                    <?php echo e($expense->transaction_with); ?> - <?php echo e($expense->reference); ?>

                                                <?php endif; ?>
                                            </strong>
                                        </small>
                                        <br/>
                                        <small>
                                           Payment Type:  <strong><?php echo e($expense->payment_type); ?></strong>
                                        </small>

                                    </p>
                                </div>
                                <nav class="level is-mobile">
                                    <div class="level-left">
                                        <a href="<?php echo e(route('expenses.show', $expense->id)); ?>"
                                           class="level-item"
                                           title="View user data">
                                            <span class="icon is-small"><i class="fas fa-eye"></i></span>
                                        </a>
                                        <a href="<?php echo e(route('expenses.edit', $expense->id)); ?>"
                                           class="level-item"
                                           title="View all transaction">
                                            <span class="icon is-info is-small"><i class="fas fa-edit"></i></span>
                                        </a>

                                        <?php echo delete_data('expenses.destroy',  $expense->id); ?>

                                    </div>
                                </nav>
                            </div>
                        </article>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/skeleton/tritiyo/homeland/src/views/expense/index.blade.php ENDPATH**/ ?>