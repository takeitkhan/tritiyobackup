<?php $__env->startSection('title'); ?>
    Create purchase
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Add Purchase',
            'spSubTitle' => 'Enter a purchase information',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('purchases.create'),
            'spAllData' => route('purchases.index'),
            'spSearchData' => route('purchases.search'),
            'spTitle' => 'All Income',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search purchases...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>
<?php $__env->startSection('column_left'); ?>
    <div class="columns">
        <div class="column is-8">
            <article class="panel is-primary">
                    <?php
                        if (!empty($purchase) && $purchase->id) {
                            $routeUrl = route('purchases.update', $purchase->id);
                            $method = 'PUT';
                        } else {
                            $routeUrl = route('purchases.store');
                            $method = 'post';
                        }
                    ?>

                <div class="p-5">
                    <?php echo e(Form::open(array('url' => $routeUrl, 'method' => $method, 'value' => 'PATCH', 'id' => 'add_route', 'files' => true, 'autocomplete' => 'off'))); ?>


                    <div class="columns">

                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('sand_type', 'Sand Type', array('class' => 'label'))); ?>

                                <div class="select is-small is-fullwidth">

                                    <select name="sand_type" class="">
                                        <option value="" disabled selected>Select sand</option>
                                        <option value="red" <?php echo e(!empty($purchase) && $purchase->sand_type == 'red' ? 'selected' : ''); ?> >
                                           Red
                                        </option>
                                        <option value="black" <?php echo e(!empty($purchase) && $purchase->sand_type == 'black' ? 'selected' : ''); ?> >
                                           Black
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="column is-6">
                            <div class="field width100">
                                <?php echo e(Form::label('bolgate_id', 'Bolgate', array('class' => 'label'))); ?>

                                <div class="select is-small is-fullwidth">

                                    <select name="bolgate_id" class="">
                                        <option value="" disabled selected>Select a Bolgate</option>
                                        <?php
                                            $bolgate = \Tritiyo\Homeland\Models\Bolgate::orderBy('id', 'DESC')->get();
                                        ?>

                                        <?php $__currentLoopData = $bolgate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->id); ?>" <?php echo e(!empty($purchase) && $purchase->bolgate_id == $data->id ? 'selected' : ''); ?> >
                                                <?php echo e($data->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="columns">
                        <div class="column is-8"></div>
                        <div class="column is-4">
                            <div class="field is-horizontal">
                                <div class="field-label is-small">
                                    <?php echo e(Form::label('date', 'Date', array('class' => 'label'))); ?>

                                </div>
                                <div class="field-label mr-0">
                                    <div class="field">
                                        <div class="control">
                                            <input type="text" class="input is-small has-background-disabled" name="date" value="<?php echo e(!empty($purchase) ? $purchase->date : date('Y-m-d')); ?>" readonly />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="columns">
                        <div class="column is-6">

                            <div class="field is-horizontal">
                                <div class="field-label is-small">
                                    <?php echo e(Form::label('per_unit_amount', 'Per Unit Amount', array('class' => 'label'))); ?>

                                </div>
                                <div class="field-label">
                                    <div class="field">
                                        <div class="control">
                                        <?php echo e(Form::text('per_unit_amount', $purchase->per_unit_amount ?? 0, ['class' => 'input is-small', 'placeholder' => 'Enter per unit amount...'])); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="field is-horizontal">
                                <div class="field-label is-small">
                                    <?php echo e(Form::label('loading_cost', 'Loading cost', array('class' => 'label'))); ?>

                                </div>
                                <div class="field-label">
                                    <div class="field">
                                        <div class="control">
                                        <?php echo e(Form::text('loading_cost', $purchase->loading_cost ?? 0, ['class' => 'input is-small', 'placeholder' => 'Enter Loading Cost...'])); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="field is-horizontal">
                                <div class="field-label is-small">
                                    <?php echo e(Form::label('bolgate_cost', 'Bolgate cost', array('class' => 'label'))); ?>

                                </div>
                                <div class="field-label">
                                    <div class="field">
                                        <div class="control">
                                        <?php echo e(Form::text('bolgate_cost', $purchase->bolgate_cost ?? 0, ['class' => 'input is-small', 'placeholder' => 'Enter Loading Cost...'])); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="field is-horizontal">
                                <div class="field-label is-small">
                                    <?php echo e(Form::label('unloading_cost', 'Unloading cost', array('class' => 'label'))); ?>

                                </div>
                                <div class="field-label">
                                    <div class="field">
                                        <div class="control">
                                        <?php echo e(Form::text('unloading_cost', $purchase->unloading_cost ?? 0, ['class' => 'input is-small', 'placeholder' => 'Enter Loading Cost...'])); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="column is-1">
                            <br><br> <br>
                            <h1>=</h1>
                            <br><br/>

                        </div>

                        <div class="column is-5 has-background-disabled">
                            <br><br>
                            <div class="field width100">
                                <?php echo e(Form::label('actual_amount', 'Sub Total', array('class' => 'label', 'style' => 'text-align: center'))); ?>

                                <div class="control">
                                <?php echo e(Form::text('actual_amount', $purchase->actual_amount ?? NULL, ['class' => 'input is-small has-background-disabled', 'readonly' => true, 'placeholder' => '', 'style'=> 'font-size: 25px; text-align: center'])); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="columns">
                        <div class="column is-7"></div>
                        <div class="column is-5">
                            <div class="field is-horizontal">
                                <div class="field-label is-small">
                                     <?php echo e(Form::label('qty', 'Feet', array('class' => 'label'))); ?>

                                </div>
                                <div class="field-label">
                                    <div class="field">
                                        <div class="control">
                                        <?php echo e(Form::number('qty', $purchase->qty ?? 1, ['class' => 'input is-small', 'placeholder' => 'Enter qty...'])); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="field is-horizontal">
                                <div class="field-label is-small">
                                    <?php echo e(Form::label('amount', 'Total Amount', array('class' => 'label'))); ?>

                                 </div>
                                <div class="field-label">
                                    <div class="field">
                                        <div class="control">
                                            <?php echo e(Form::text('amount', $purchase->amount ?? NULL, ['class' => 'input is-small has-background-disabled', 'readonly' => true, 'placeholder' => 'Enter Amount...'])); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="columns">
                        <div class="column is-5">

                        </div>

                    </div>

                    <div class="columns">
                        <div class="column">
                            <div class="field is-grouped">
                                <div class="control">
                                    <button class="button is-success is-small">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </article>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('column_right'); ?>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('cusjs'); ?>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>




<script>


// Amount Disocunt Calculation
let perUnitAmount = $('input#per_unit_amount').val();
let loadingCost = $('input#loading_cost').val();
let bolgateCost = $('input#bolgate_cost').val();
let unloadingCost = $('input#unloading_cost').val()

let actualAmount = 0;
let qty = $('input#qty').val();


$('input#per_unit_amount').keyup(function(){
    perUnitAmount = $(this).val();
    actualAmount = parseFloat(perUnitAmount) + parseFloat(loadingCost) + parseFloat(bolgateCost) + parseFloat(unloadingCost);
    $('input#actual_amount').val(actualAmount);
    $('input#amount').val(actualAmount*qty);
})


$('input#loading_cost').keyup(function(){
    loadingCost = $(this).val();
    actualAmount = parseFloat(perUnitAmount) + parseFloat(loadingCost) + parseFloat(bolgateCost) + parseFloat(unloadingCost);
    $('input#actual_amount').val(actualAmount);
    $('input#amount').val(actualAmount*qty);
})


$('input#bolgate_cost').keyup(function(){
    bolgateCost = $(this).val();
    actualAmount = parseFloat(perUnitAmount) + parseFloat(loadingCost) + parseFloat(bolgateCost) + parseFloat(unloadingCost);
    $('input#actual_amount').val(actualAmount);
    $('input#amount').val(actualAmount*qty);
})


$('input#unloading_cost').keyup(function(){
    unloadingCost = $(this).val();
    actualAmount = parseFloat(perUnitAmount) + parseFloat(loadingCost) + parseFloat(bolgateCost) + parseFloat(unloadingCost);
    $('input#actual_amount').val(actualAmount);

    $('input#amount').val(actualAmount*qty);
})

$('input#qty').keyup(function(){
    qty = $(this).val();
    $('input#amount').val(actualAmount*qty);
})

//console.log(actualAmount);

// $('input#amount').val($('input#actual_amount').val()*2);

/*
let qty = $('input#qty').val();
$('input#qty').keyup(function(){
    qty = $(this).val();
    $('input#actual_amount').val(perUnitAmount*qty);
    $('input#amount').val((perUnitAmount*qty)-discount);
})


let discount = $('input#discount').val();
$('input#discount').keyup(function(){
    discount = $('input#discount').val();
    //console.log(actualAmount)
    $('input#amount').val((perUnitAmount*qty)-discount);
})
*/

/*
let actualAmount = 0;
$('input#actual_amount').keyup(function(){
    actualAmount = $(this).val();
    //let discount = $('input#discount').val();
    $('input#amount').val(actualAmount - discount);
})
*/


//$('input#amount').val()

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/skeleton/tritiyo/homeland/src/views/purchase/create.blade.php ENDPATH**/ ?>