<?php $__env->startSection('title'); ?>
    Ledgers
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Ledger',
            'spSubTitle' => 'all ledgers here',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('ledgers.create'),
            'spAllData' => route('ledgers.index'),
            'spSearchData' => route('ledgers.search'),
            'spTitle' => 'All Ledger',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search ledgers...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>

<?php $__env->startSection('column_left'); ?>
    <div class="columns is-multiline">
        <?php if(!empty($ledgers)): ?>
            <?php $__currentLoopData = $ledgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column is-2">
                    <div class="borderedCol">
                        <article class="media">
                            <div class="media-content">
                                <div class="content">
                                    <p>
                                        <strong>
                                            <a href="<?php echo e(route('ledgers.show', $ledger->id)); ?>"
                                               title="View route">
                                               <strong> <?php echo e($ledger->name); ?> </strong>
                                            </a>
                                        </strong>
                                        <br/>
                                        <small>
                                            <strong>Type: </strong> <?php echo e($ledger->type); ?>

                                        </small>
                                        <br/>
                                    </p>
                                </div>
                                <nav class="level is-mobile">
                                    <div class="level-left">
                                        <a href="<?php echo e(route('ledgers.show', $ledger->id)); ?>"
                                           class="level-item"
                                           title="View user data">
                                            <span class="icon is-small"><i class="fas fa-eye"></i></span>
                                        </a>
                                        <a href="<?php echo e(route('ledgers.edit', $ledger->id)); ?>"
                                           class="level-item"
                                           title="View all transaction">
                                            <span class="icon is-info is-small"><i class="fas fa-edit"></i></span>
                                        </a>

                                        <?php echo delete_data('ledgers.destroy',  $ledger->id); ?>

                                    </div>
                                </nav>
                            </div>
                        </article>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/skeleton/tritiyo/homeland/src/views/ledger/index.blade.php ENDPATH**/ ?>