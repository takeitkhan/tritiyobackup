<?php $__env->startSection('title'); ?>
    Create Customer
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Customer',
            'spSubTitle' => 'Enter a customer information',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('customers.create'),
            'spAllData' => route('customers.index'),
            'spSearchData' => route('customers.search'),
            'spTitle' => 'All Customer',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search customers...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>
<?php $__env->startSection('column_left'); ?>
    <article class="panel is-primary">
            <?php
                if (!empty($customer) && $customer->id) {
                    $routeUrl = route('customers.update', $customer->id);
                    $method = 'PUT';
                } else {
                    $routeUrl = route('customers.store');
                    $method = 'post';
                }
            ?>

        <div class="customContainer">
            <?php echo e(Form::open(array('url' => $routeUrl, 'method' => $method, 'value' => 'PATCH', 'id' => 'add_route', 'files' => true, 'autocomplete' => 'off'))); ?>

            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <?php echo e(Form::label('name', 'Name', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::text('name', $customer->name ?? NULL, ['class' => 'input is-small', 'placeholder' => 'Enter name...'])); ?>

                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <?php echo e(Form::label('phone', 'Phone', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::text('phone', $customer->phone ?? NULL, ['class' => 'input is-small', 'placeholder' => 'Enter phone...'])); ?>

                        </div>
                    </div>
                </div>

                <div class="column is-4">
                    <div class="field">
                        <?php echo e(Form::label('company', 'Company', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::text('company', $customer->company ?? NULL, ['class' => 'input is-small', 'placeholder' => 'Enter company...'])); ?>

                        </div>
                    </div>
                </div>


            </div>

            <div class="columns">
                 <div class="column is-6">
                    <div class="field">
                        <?php echo e(Form::label('mobile_bank_account', 'Mobile Bank Account', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::textarea('mobile_bank_account', $customer->mobile_bank_account ?? NULL, ['class' => 'textarea is-small', 'placeholder' => 'Enter mobile bank account details...', 'rows' => '4'])); ?>

                        </div>
                    </div>
                </div>

                <div class="column is-6">
                    <div class="field">
                        <?php echo e(Form::label('bank_account', 'Bank Account Details', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::textarea('bank_account', $customer->bank_account ?? NULL, ['class' => 'textarea is-small', 'placeholder' => 'Enter bank account details...', 'rows' => '4'])); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <?php echo e(Form::label('address', 'Address', array('class' => 'label'))); ?>

                        <div class="control">
                            <?php echo e(Form::text('address', $customer->address ?? NULL, ['class' => 'input is-small', 'placeholder' => 'Enter address...'])); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="columns">
                <div class="column">
                    <div class="field is-grouped">
                        <div class="control">
                            <button class="button is-success is-small">Save Changes</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('column_right'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/skeleton/tritiyo/homeland/src/views/customer/create.blade.php ENDPATH**/ ?>