<?php $__env->startSection('title'); ?>
    Single Bolgate
<?php $__env->stopSection(); ?>

<section class="hero is-white borderBtmLight">
    <nav class="level">
        <?php echo $__env->make('component.title_set', [
            'spTitle' => 'Single Bolgate',
            'spSubTitle' => 'view a Bolgate',
            'spShowTitleSet' => true
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.button_set', [
            'spShowButtonSet' => true,
            'spAddUrl' => null,
            'spAddUrl' => route('bolgates.create'),
            'spAllData' => route('bolgates.index'),
            'spSearchData' => route('bolgates.search'),
            'spTitle' => 'All Bolgate',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('component.filter_set', [
            'spShowFilterSet' => true,
            'spPlaceholder' => 'Search bolgates...',
            'spMessage' => $message = $message ?? NULl,
            'spStatus' => $status = $status ?? NULL
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</section>
<?php $__env->startSection('column_left'); ?>
    
    
    <div class="card tile is-child">
        <header class="card-header">
            <p class="card-header-title">
                <span class="icon"><i class="mdi mdi-account default"></i></span>
                Main Bolgate Data
            </p>
        </header>
        <div class="card-content">
            <div class="card-data">
                <div class="columns">
                    <div class="column is-2">Name</div>
                    <div class="column is-1">:</div>
                    <div class="column"><?php echo e($bolgate->name); ?></div>
                </div>
                <div class="columns">
                    <div class="column is-2">Bolgate size</div>
                    <div class="column is-1">:</div>
                    <div class="column"><?php echo e($bolgate->size); ?></div>
                </div>
                <div class="columns">
                    <div class="column is-2">Owner</div>
                    <div class="column is-1">:</div>
                    <div class="column"><?php echo e($bolgate->owner); ?></div>
                </div>
                <div class="columns">
                    <div class="column is-2">Fuel Capacity</div>
                    <div class="column is-1">:</div>
                    <div class="column"><?php echo e($bolgate->fuel_capacity); ?></div>
                </div>
                <div class="columns">
                    <div class="column is-2">Description</div>
                    <div class="column is-1">:</div>
                    <div class="column"><?php echo e($bolgate->description); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('column_right'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('cusjs'); ?>
    <style type="text/css">
        .table.is-fullwidth {
            width: 100%;
            font-size: 15px;
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/skeleton/tritiyo/homeland/src/views/bolgate/show.blade.php ENDPATH**/ ?>