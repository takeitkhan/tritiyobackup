<?php get_header();?>

<?php 
include_once get_template_directory() .'/inc/homepage/slider.php';
include_once get_template_directory() .'/inc/homepage/second-section.php';
include_once get_template_directory() .'/inc/homepage/third-section.php';
include_once get_template_directory() .'/inc/homepage/service-section.php';
include_once get_template_directory() .'/inc/homepage/client-section.php';
include_once get_template_directory() .'/inc/homepage/blog-section.php';

?>



<?php get_footer() ;?>