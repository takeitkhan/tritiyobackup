<?php include 'inc/header.php';?>

<section class="breadcrumb-area banner-2">
   <div class="text-block">
      <div class="container">
         <div class="row">
            <div class="col-lg-12 v-center">
               <div class="bread-inner">
                  <div class="bread-menu">
                     <ul>
                        <li><a href="index-2.html">Home</a></li>
                        <li><a href="#">Single Page</a></li>
                     </ul>
                  </div>
                  <div class="bread-title">
                     <h2>Single Page</h2>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>


<section class="service pad-tb">
   <div class="container">
      <div class="row">
         <div class="col-lg-12 block-1">
            <div class="common-heading text-l pr25">
               <h2>Single Content</h2>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry. is simply dummy text of the printing and typesetting industry. </p>
               <h5 class="mt20 mb10">Vision Statement</h5>
               <ul class="list-style-">
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                  <li>Nullam porta nulla in sapien molestie, ut finibus nisi euismod.</li>
                  <li>Curabitur euismod elit sed venenatis porttitor.</li>
                  <li>Morbi convallis dolor ut tincidunt porttitor.</li>
                  <li>Phasellus eleifend massa non enim elementum, a venenatis erat sollicitudin.</li>
                  <li>Aenean sit amet elit euismod, aliquam quam eu, semper tellus.</li>
                  <li>Maecenas sed ligula tristique, vestibulum tellus nec, dictum nisl.</li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</section>



<?php include 'inc/footer.php' ;?>